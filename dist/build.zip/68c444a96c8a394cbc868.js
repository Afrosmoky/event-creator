import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=304.06 height=300 fill=none viewBox="99.86 108.63 312.06 308"><path stroke=#000 stroke-miterlimit=10 stroke-width=5 d="M103.86 412.13h300"></path><path stroke=#000 stroke-dasharray="12 12"stroke-miterlimit=10 stroke-width=5 d="M104.36 412.63v-300M107.3 112.63c164.43 0 298.35 132.12 300.57 296.54l.05 3.46M116.36 125.13l-9.07-12.5">`);
const left_door = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { left_door as default };
