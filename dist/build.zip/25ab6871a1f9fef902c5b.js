import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=150 height=150 fill=none viewBox="177 177 158 158"><path fill=#000 d="M331 181H181v150h150z">`);
const pillar = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { pillar as default };
