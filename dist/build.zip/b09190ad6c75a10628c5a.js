import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=307.014 height=293.474 fill=none viewBox="98.397 102.226 315.014 301.474"><path stroke=#000 stroke-width=10 d="M284.225 106.226 221.992 399.7"></path><path fill=#000 stroke=#000 stroke-miterlimit=10 stroke-width=5 d="M161 167c-13.807 0-25-11.193-25-25s11.193-25 25-25 25 11.193 25 25-11.193 25-25 25ZM351 167c-13.807 0-25-11.193-25-25s11.193-25 25-25 25 11.193 25 25-11.193 25-25 25Z"></path><path fill=#000 stroke=#000 stroke-width=5 d="M343.913 203.096c2.33-6.727 11.844-6.727 14.174 0l50.905 146.949c1.687 4.872-1.931 9.955-7.087 9.955h-101.81c-5.156 0-8.774-5.083-7.087-9.955zM167.214 353.276c-2.361 6.716-11.874 6.673-14.174-.065l-50.235-147.179c-1.665-4.88 1.976-9.946 7.132-9.923l101.809.464c5.156.023 8.751 5.122 7.041 9.987z">`);
const toiletSign = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { toiletSign as default };
