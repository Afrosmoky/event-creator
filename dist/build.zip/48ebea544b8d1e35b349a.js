import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=0 fill=none viewBox="102 252 308 8"><path stroke=#000 stroke-miterlimit=10 stroke-width=5 d="M106 256h300">`);
const strainghtWall = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { strainghtWall as default };
