import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=256 cy=256 r=150 stroke=#000 stroke-linejoin=round stroke-width=5></circle><path stroke=#000 stroke-width=5 d="M139.5 248.5h145v15h-145z"></path><path stroke=#000 stroke-linecap=square stroke-width=5 d="M161.5 250.5v13"></path><path stroke=#000 stroke-linecap=round stroke-width=3 d="M346 175s-48 13.655-48 28.5 19.061 11.903 22.371 22.81C324.758 240.767 298 247 298 247"></path><path stroke=#000 stroke-linecap=round stroke-width=3 d="M334.065 193s-17.797 5.508-16.065 12c1.733 6.492 13.791 6.5 18 13.5 3.588 5.968-1.935 15-1.935 15"></path><path stroke=#000 stroke-linecap=round stroke-width=3 d="M354.5 190c-14.5 27.5 18.5 9.087 18.5 23.565s-18.604 17.296-21.5 27.935c-3.839 14.099-52 16-52 16">`);
const smoke = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { smoke as default };
