const IS_DEV = false;
const equalFn = (a, b) => a === b;
const $PROXY = Symbol("solid-proxy");
const SUPPORTS_PROXY = typeof Proxy === "function";
const $TRACK = Symbol("solid-track");
const signalOptions = {
  equals: equalFn
};
let runEffects = runQueue;
const STALE = 1;
const PENDING = 2;
const UNOWNED = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
const NO_INIT = {};
var Owner = null;
let Transition = null;
let ExternalSourceConfig = null;
let Listener = null;
let Updates = null;
let Effects = null;
let ExecCount = 0;
function createRoot(fn, detachedOwner) {
  const listener = Listener,
    owner = Owner,
    unowned = fn.length === 0,
    current = detachedOwner === undefined ? owner : detachedOwner,
    root = unowned ? UNOWNED : {
      owned: null,
      cleanups: null,
      context: current ? current.context : null,
      owner: current
    },
    updateFn = unowned ? fn : () => fn(() => untrack(() => cleanNode(root)));
  Owner = root;
  Listener = null;
  try {
    return runUpdates(updateFn, true);
  } finally {
    Listener = listener;
    Owner = owner;
  }
}
function createSignal(value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const s = {
    value,
    observers: null,
    observerSlots: null,
    comparator: options.equals || undefined
  };
  const setter = value => {
    if (typeof value === "function") {
      value = value(s.value);
    }
    return writeSignal(s, value);
  };
  return [readSignal.bind(s), setter];
}
function createComputed(fn, value, options) {
  const c = createComputation(fn, value, true, STALE);
  updateComputation(c);
}
function createRenderEffect(fn, value, options) {
  const c = createComputation(fn, value, false, STALE);
  updateComputation(c);
}
function createEffect(fn, value, options) {
  runEffects = runUserEffects;
  const c = createComputation(fn, value, false, STALE);
  c.user = true;
  Effects ? Effects.push(c) : updateComputation(c);
}
function createMemo(fn, value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const c = createComputation(fn, value, true, 0);
  c.observers = null;
  c.observerSlots = null;
  c.comparator = options.equals || undefined;
  updateComputation(c);
  return readSignal.bind(c);
}
function isPromise(v) {
  return v && typeof v === "object" && "then" in v;
}
function createResource(pSource, pFetcher, pOptions) {
  let source;
  let fetcher;
  let options;
  if (typeof pFetcher === "function") {
    source = pSource;
    fetcher = pFetcher;
    options = {};
  } else {
    source = true;
    fetcher = pSource;
    options = pFetcher || {};
  }
  let pr = null,
    initP = NO_INIT,
    scheduled = false,
    resolved = "initialValue" in options,
    dynamic = typeof source === "function" && createMemo(source);
  const contexts = new Set(),
    [value, setValue] = (options.storage || createSignal)(options.initialValue),
    [error, setError] = createSignal(undefined),
    [track, trigger] = createSignal(undefined, {
      equals: false
    }),
    [state, setState] = createSignal(resolved ? "ready" : "unresolved");
  function loadEnd(p, v, error, key) {
    if (pr === p) {
      pr = null;
      key !== undefined && (resolved = true);
      if ((p === initP || v === initP) && options.onHydrated) queueMicrotask(() => options.onHydrated(key, {
        value: v
      }));
      initP = NO_INIT;
      completeLoad(v, error);
    }
    return v;
  }
  function completeLoad(v, err) {
    runUpdates(() => {
      if (err === undefined) setValue(() => v);
      setState(err !== undefined ? "errored" : resolved ? "ready" : "unresolved");
      setError(err);
      for (const c of contexts.keys()) c.decrement();
      contexts.clear();
    }, false);
  }
  function read() {
    const c = SuspenseContext,
      v = value(),
      err = error();
    if (err !== undefined && !pr) throw err;
    if (Listener && !Listener.user && c) ;
    return v;
  }
  function load(refetching = true) {
    if (refetching !== false && scheduled) return;
    scheduled = false;
    const lookup = dynamic ? dynamic() : source;
    if (lookup == null || lookup === false) {
      loadEnd(pr, untrack(value));
      return;
    }
    let error;
    const p = initP !== NO_INIT ? initP : untrack(() => {
      try {
        return fetcher(lookup, {
          value: value(),
          refetching
        });
      } catch (fetcherError) {
        error = fetcherError;
      }
    });
    if (error !== undefined) {
      loadEnd(pr, undefined, castError(error), lookup);
      return;
    } else if (!isPromise(p)) {
      loadEnd(pr, p, undefined, lookup);
      return p;
    }
    pr = p;
    if ("v" in p) {
      if (p.s === 1) loadEnd(pr, p.v, undefined, lookup);else loadEnd(pr, undefined, castError(p.v), lookup);
      return p;
    }
    scheduled = true;
    queueMicrotask(() => scheduled = false);
    runUpdates(() => {
      setState(resolved ? "refreshing" : "pending");
      trigger();
    }, false);
    return p.then(v => loadEnd(p, v, undefined, lookup), e => loadEnd(p, undefined, castError(e), lookup));
  }
  Object.defineProperties(read, {
    state: {
      get: () => state()
    },
    error: {
      get: () => error()
    },
    loading: {
      get() {
        const s = state();
        return s === "pending" || s === "refreshing";
      }
    },
    latest: {
      get() {
        if (!resolved) return read();
        const err = error();
        if (err && !pr) throw err;
        return value();
      }
    }
  });
  let owner = Owner;
  if (dynamic) createComputed(() => (owner = Owner, load(false)));else load(false);
  return [read, {
    refetch: info => runWithOwner(owner, () => load(info)),
    mutate: setValue
  }];
}
function batch(fn) {
  return runUpdates(fn, false);
}
function untrack(fn) {
  if (Listener === null) return fn();
  const listener = Listener;
  Listener = null;
  try {
    if (ExternalSourceConfig) ;
    return fn();
  } finally {
    Listener = listener;
  }
}
function on(deps, fn, options) {
  const isArray = Array.isArray(deps);
  let prevInput;
  let defer = options && options.defer;
  return prevValue => {
    let input;
    if (isArray) {
      input = Array(deps.length);
      for (let i = 0; i < deps.length; i++) input[i] = deps[i]();
    } else input = deps();
    if (defer) {
      defer = false;
      return prevValue;
    }
    const result = untrack(() => fn(input, prevInput, prevValue));
    prevInput = input;
    return result;
  };
}
function onMount(fn) {
  createEffect(() => untrack(fn));
}
function onCleanup(fn) {
  if (Owner === null) ;else if (Owner.cleanups === null) Owner.cleanups = [fn];else Owner.cleanups.push(fn);
  return fn;
}
function getListener() {
  return Listener;
}
function getOwner() {
  return Owner;
}
function runWithOwner(o, fn) {
  const prev = Owner;
  const prevListener = Listener;
  Owner = o;
  Listener = null;
  try {
    return runUpdates(fn, true);
  } catch (err) {
    handleError(err);
  } finally {
    Owner = prev;
    Listener = prevListener;
  }
}
function startTransition(fn) {
  const l = Listener;
  const o = Owner;
  return Promise.resolve().then(() => {
    Listener = l;
    Owner = o;
    let t;
    runUpdates(fn, false);
    Listener = Owner = null;
    return t ? t.done : undefined;
  });
}
const [transPending, setTransPending] = /*@__PURE__*/createSignal(false);
function createContext(defaultValue, options) {
  const id = Symbol("context");
  return {
    id,
    Provider: createProvider(id),
    defaultValue
  };
}
function useContext(context) {
  let value;
  return Owner && Owner.context && (value = Owner.context[context.id]) !== undefined ? value : context.defaultValue;
}
function children(fn) {
  const children = createMemo(fn);
  const memo = createMemo(() => resolveChildren(children()));
  memo.toArray = () => {
    const c = memo();
    return Array.isArray(c) ? c : c != null ? [c] : [];
  };
  return memo;
}
let SuspenseContext;
function readSignal() {
  if (this.sources && (this.state)) {
    if ((this.state) === STALE) updateComputation(this);else {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(this), false);
      Updates = updates;
    }
  }
  if (Listener) {
    const sSlot = this.observers ? this.observers.length : 0;
    if (!Listener.sources) {
      Listener.sources = [this];
      Listener.sourceSlots = [sSlot];
    } else {
      Listener.sources.push(this);
      Listener.sourceSlots.push(sSlot);
    }
    if (!this.observers) {
      this.observers = [Listener];
      this.observerSlots = [Listener.sources.length - 1];
    } else {
      this.observers.push(Listener);
      this.observerSlots.push(Listener.sources.length - 1);
    }
  }
  return this.value;
}
function writeSignal(node, value, isComp) {
  let current = node.value;
  if (!node.comparator || !node.comparator(current, value)) {
    node.value = value;
    if (node.observers && node.observers.length) {
      runUpdates(() => {
        for (let i = 0; i < node.observers.length; i += 1) {
          const o = node.observers[i];
          const TransitionRunning = Transition && Transition.running;
          if (TransitionRunning && Transition.disposed.has(o)) ;
          if (TransitionRunning ? !o.tState : !o.state) {
            if (o.pure) Updates.push(o);else Effects.push(o);
            if (o.observers) markDownstream(o);
          }
          if (!TransitionRunning) o.state = STALE;
        }
        if (Updates.length > 10e5) {
          Updates = [];
          if (IS_DEV) ;
          throw new Error();
        }
      }, false);
    }
  }
  return value;
}
function updateComputation(node) {
  if (!node.fn) return;
  cleanNode(node);
  const time = ExecCount;
  runComputation(node, node.value, time);
}
function runComputation(node, value, time) {
  let nextValue;
  const owner = Owner,
    listener = Listener;
  Listener = Owner = node;
  try {
    nextValue = node.fn(value);
  } catch (err) {
    if (node.pure) {
      {
        node.state = STALE;
        node.owned && node.owned.forEach(cleanNode);
        node.owned = null;
      }
    }
    node.updatedAt = time + 1;
    return handleError(err);
  } finally {
    Listener = listener;
    Owner = owner;
  }
  if (!node.updatedAt || node.updatedAt <= time) {
    if (node.updatedAt != null && "observers" in node) {
      writeSignal(node, nextValue);
    } else node.value = nextValue;
    node.updatedAt = time;
  }
}
function createComputation(fn, init, pure, state = STALE, options) {
  const c = {
    fn,
    state: state,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: init,
    owner: Owner,
    context: Owner ? Owner.context : null,
    pure
  };
  if (Owner === null) ;else if (Owner !== UNOWNED) {
    {
      if (!Owner.owned) Owner.owned = [c];else Owner.owned.push(c);
    }
  }
  return c;
}
function runTop(node) {
  if ((node.state) === 0) return;
  if ((node.state) === PENDING) return lookUpstream(node);
  if (node.suspense && untrack(node.suspense.inFallback)) return node.suspense.effects.push(node);
  const ancestors = [node];
  while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
    if (node.state) ancestors.push(node);
  }
  for (let i = ancestors.length - 1; i >= 0; i--) {
    node = ancestors[i];
    if ((node.state) === STALE) {
      updateComputation(node);
    } else if ((node.state) === PENDING) {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(node, ancestors[0]), false);
      Updates = updates;
    }
  }
}
function runUpdates(fn, init) {
  if (Updates) return fn();
  let wait = false;
  if (!init) Updates = [];
  if (Effects) wait = true;else Effects = [];
  ExecCount++;
  try {
    const res = fn();
    completeUpdates(wait);
    return res;
  } catch (err) {
    if (!wait) Effects = null;
    Updates = null;
    handleError(err);
  }
}
function completeUpdates(wait) {
  if (Updates) {
    runQueue(Updates);
    Updates = null;
  }
  if (wait) return;
  const e = Effects;
  Effects = null;
  if (e.length) runUpdates(() => runEffects(e), false);
}
function runQueue(queue) {
  for (let i = 0; i < queue.length; i++) runTop(queue[i]);
}
function runUserEffects(queue) {
  let i,
    userLength = 0;
  for (i = 0; i < queue.length; i++) {
    const e = queue[i];
    if (!e.user) runTop(e);else queue[userLength++] = e;
  }
  for (i = 0; i < userLength; i++) runTop(queue[i]);
}
function lookUpstream(node, ignore) {
  node.state = 0;
  for (let i = 0; i < node.sources.length; i += 1) {
    const source = node.sources[i];
    if (source.sources) {
      const state = source.state;
      if (state === STALE) {
        if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount)) runTop(source);
      } else if (state === PENDING) lookUpstream(source, ignore);
    }
  }
}
function markDownstream(node) {
  for (let i = 0; i < node.observers.length; i += 1) {
    const o = node.observers[i];
    if (!o.state) {
      o.state = PENDING;
      if (o.pure) Updates.push(o);else Effects.push(o);
      o.observers && markDownstream(o);
    }
  }
}
function cleanNode(node) {
  let i;
  if (node.sources) {
    while (node.sources.length) {
      const source = node.sources.pop(),
        index = node.sourceSlots.pop(),
        obs = source.observers;
      if (obs && obs.length) {
        const n = obs.pop(),
          s = source.observerSlots.pop();
        if (index < obs.length) {
          n.sourceSlots[s] = index;
          obs[index] = n;
          source.observerSlots[index] = s;
        }
      }
    }
  }
  if (node.tOwned) {
    for (i = node.tOwned.length - 1; i >= 0; i--) cleanNode(node.tOwned[i]);
    delete node.tOwned;
  }
  if (node.owned) {
    for (i = node.owned.length - 1; i >= 0; i--) cleanNode(node.owned[i]);
    node.owned = null;
  }
  if (node.cleanups) {
    for (i = node.cleanups.length - 1; i >= 0; i--) node.cleanups[i]();
    node.cleanups = null;
  }
  node.state = 0;
}
function castError(err) {
  if (err instanceof Error) return err;
  return new Error(typeof err === "string" ? err : "Unknown error", {
    cause: err
  });
}
function handleError(err, owner = Owner) {
  const error = castError(err);
  throw error;
}
function resolveChildren(children) {
  if (typeof children === "function" && !children.length) return resolveChildren(children());
  if (Array.isArray(children)) {
    const results = [];
    for (let i = 0; i < children.length; i++) {
      const result = resolveChildren(children[i]);
      Array.isArray(result) ? results.push.apply(results, result) : results.push(result);
    }
    return results;
  }
  return children;
}
function createProvider(id, options) {
  return function provider(props) {
    let res;
    createRenderEffect(() => res = untrack(() => {
      Owner.context = {
        ...Owner.context,
        [id]: props.value
      };
      return children(() => props.children);
    }), undefined);
    return res;
  };
}

const FALLBACK = Symbol("fallback");
function dispose(d) {
  for (let i = 0; i < d.length; i++) d[i]();
}
function mapArray(list, mapFn, options = {}) {
  let items = [],
    mapped = [],
    disposers = [],
    len = 0,
    indexes = mapFn.length > 1 ? [] : null;
  onCleanup(() => dispose(disposers));
  return () => {
    let newItems = list() || [],
      newLen = newItems.length,
      i,
      j;
    newItems[$TRACK];
    return untrack(() => {
      let newIndices, newIndicesNext, temp, tempdisposers, tempIndexes, start, end, newEnd, item;
      if (newLen === 0) {
        if (len !== 0) {
          dispose(disposers);
          disposers = [];
          items = [];
          mapped = [];
          len = 0;
          indexes && (indexes = []);
        }
        if (options.fallback) {
          items = [FALLBACK];
          mapped[0] = createRoot(disposer => {
            disposers[0] = disposer;
            return options.fallback();
          });
          len = 1;
        }
      }
      else if (len === 0) {
        mapped = new Array(newLen);
        for (j = 0; j < newLen; j++) {
          items[j] = newItems[j];
          mapped[j] = createRoot(mapper);
        }
        len = newLen;
      } else {
        temp = new Array(newLen);
        tempdisposers = new Array(newLen);
        indexes && (tempIndexes = new Array(newLen));
        for (start = 0, end = Math.min(len, newLen); start < end && items[start] === newItems[start]; start++);
        for (end = len - 1, newEnd = newLen - 1; end >= start && newEnd >= start && items[end] === newItems[newEnd]; end--, newEnd--) {
          temp[newEnd] = mapped[end];
          tempdisposers[newEnd] = disposers[end];
          indexes && (tempIndexes[newEnd] = indexes[end]);
        }
        newIndices = new Map();
        newIndicesNext = new Array(newEnd + 1);
        for (j = newEnd; j >= start; j--) {
          item = newItems[j];
          i = newIndices.get(item);
          newIndicesNext[j] = i === undefined ? -1 : i;
          newIndices.set(item, j);
        }
        for (i = start; i <= end; i++) {
          item = items[i];
          j = newIndices.get(item);
          if (j !== undefined && j !== -1) {
            temp[j] = mapped[i];
            tempdisposers[j] = disposers[i];
            indexes && (tempIndexes[j] = indexes[i]);
            j = newIndicesNext[j];
            newIndices.set(item, j);
          } else disposers[i]();
        }
        for (j = start; j < newLen; j++) {
          if (j in temp) {
            mapped[j] = temp[j];
            disposers[j] = tempdisposers[j];
            if (indexes) {
              indexes[j] = tempIndexes[j];
              indexes[j](j);
            }
          } else mapped[j] = createRoot(mapper);
        }
        mapped = mapped.slice(0, len = newLen);
        items = newItems.slice(0);
      }
      return mapped;
    });
    function mapper(disposer) {
      disposers[j] = disposer;
      if (indexes) {
        const [s, set] = createSignal(j);
        indexes[j] = set;
        return mapFn(newItems[j], s);
      }
      return mapFn(newItems[j]);
    }
  };
}
function createComponent(Comp, props) {
  return untrack(() => Comp(props || {}));
}
function trueFn() {
  return true;
}
const propTraps = {
  get(_, property, receiver) {
    if (property === $PROXY) return receiver;
    return _.get(property);
  },
  has(_, property) {
    if (property === $PROXY) return true;
    return _.has(property);
  },
  set: trueFn,
  deleteProperty: trueFn,
  getOwnPropertyDescriptor(_, property) {
    return {
      configurable: true,
      enumerable: true,
      get() {
        return _.get(property);
      },
      set: trueFn,
      deleteProperty: trueFn
    };
  },
  ownKeys(_) {
    return _.keys();
  }
};
function resolveSource(s) {
  return !(s = typeof s === "function" ? s() : s) ? {} : s;
}
function resolveSources() {
  for (let i = 0, length = this.length; i < length; ++i) {
    const v = this[i]();
    if (v !== undefined) return v;
  }
}
function mergeProps(...sources) {
  let proxy = false;
  for (let i = 0; i < sources.length; i++) {
    const s = sources[i];
    proxy = proxy || !!s && $PROXY in s;
    sources[i] = typeof s === "function" ? (proxy = true, createMemo(s)) : s;
  }
  if (SUPPORTS_PROXY && proxy) {
    return new Proxy({
      get(property) {
        for (let i = sources.length - 1; i >= 0; i--) {
          const v = resolveSource(sources[i])[property];
          if (v !== undefined) return v;
        }
      },
      has(property) {
        for (let i = sources.length - 1; i >= 0; i--) {
          if (property in resolveSource(sources[i])) return true;
        }
        return false;
      },
      keys() {
        const keys = [];
        for (let i = 0; i < sources.length; i++) keys.push(...Object.keys(resolveSource(sources[i])));
        return [...new Set(keys)];
      }
    }, propTraps);
  }
  const sourcesMap = {};
  const defined = Object.create(null);
  for (let i = sources.length - 1; i >= 0; i--) {
    const source = sources[i];
    if (!source) continue;
    const sourceKeys = Object.getOwnPropertyNames(source);
    for (let i = sourceKeys.length - 1; i >= 0; i--) {
      const key = sourceKeys[i];
      if (key === "__proto__" || key === "constructor") continue;
      const desc = Object.getOwnPropertyDescriptor(source, key);
      if (!defined[key]) {
        defined[key] = desc.get ? {
          enumerable: true,
          configurable: true,
          get: resolveSources.bind(sourcesMap[key] = [desc.get.bind(source)])
        } : desc.value !== undefined ? desc : undefined;
      } else {
        const sources = sourcesMap[key];
        if (sources) {
          if (desc.get) sources.push(desc.get.bind(source));else if (desc.value !== undefined) sources.push(() => desc.value);
        }
      }
    }
  }
  const target = {};
  const definedKeys = Object.keys(defined);
  for (let i = definedKeys.length - 1; i >= 0; i--) {
    const key = definedKeys[i],
      desc = defined[key];
    if (desc && desc.get) Object.defineProperty(target, key, desc);else target[key] = desc ? desc.value : undefined;
  }
  return target;
}
function splitProps(props, ...keys) {
  const len = keys.length;
  if (SUPPORTS_PROXY && $PROXY in props) {
    const blocked = len > 1 ? keys.flat() : keys[0];
    const res = keys.map(k => {
      return new Proxy({
        get(property) {
          return k.includes(property) ? props[property] : undefined;
        },
        has(property) {
          return k.includes(property) && property in props;
        },
        keys() {
          return k.filter(property => property in props);
        }
      }, propTraps);
    });
    res.push(new Proxy({
      get(property) {
        return blocked.includes(property) ? undefined : props[property];
      },
      has(property) {
        return blocked.includes(property) ? false : property in props;
      },
      keys() {
        return Object.keys(props).filter(k => !blocked.includes(k));
      }
    }, propTraps));
    return res;
  }
  const objects = [];
  for (let i = 0; i <= len; i++) {
    objects[i] = {};
  }
  for (const propName of Object.getOwnPropertyNames(props)) {
    let keyIndex = len;
    for (let i = 0; i < keys.length; i++) {
      if (keys[i].includes(propName)) {
        keyIndex = i;
        break;
      }
    }
    const desc = Object.getOwnPropertyDescriptor(props, propName);
    const isDefaultDesc = !desc.get && !desc.set && desc.enumerable && desc.writable && desc.configurable;
    isDefaultDesc ? objects[keyIndex][propName] = desc.value : Object.defineProperty(objects[keyIndex], propName, desc);
  }
  return objects;
}

const narrowedError = name => `Stale read from <${name}>.`;
function For(props) {
  const fallback = "fallback" in props && {
    fallback: () => props.fallback
  };
  return createMemo(mapArray(() => props.each, props.children, fallback || undefined));
}
function Show(props) {
  const keyed = props.keyed;
  const conditionValue = createMemo(() => props.when, undefined, undefined);
  const condition = keyed ? conditionValue : createMemo(conditionValue, undefined, {
    equals: (a, b) => !a === !b
  });
  return createMemo(() => {
    const c = condition();
    if (c) {
      const child = props.children;
      const fn = typeof child === "function" && child.length > 0;
      return fn ? untrack(() => child(keyed ? c : () => {
        if (!untrack(condition)) throw narrowedError("Show");
        return conditionValue();
      })) : child;
    }
    return props.fallback;
  }, undefined, undefined);
}
function Switch(props) {
  const chs = children(() => props.children);
  const switchFunc = createMemo(() => {
    const ch = chs();
    const mps = Array.isArray(ch) ? ch : [ch];
    let func = () => undefined;
    for (let i = 0; i < mps.length; i++) {
      const index = i;
      const mp = mps[i];
      const prevFunc = func;
      const conditionValue = createMemo(() => prevFunc() ? undefined : mp.when, undefined, undefined);
      const condition = mp.keyed ? conditionValue : createMemo(conditionValue, undefined, {
        equals: (a, b) => !a === !b
      });
      func = () => prevFunc() || (condition() ? [index, conditionValue, mp] : undefined);
    }
    return func;
  });
  return createMemo(() => {
    const sel = switchFunc()();
    if (!sel) return props.fallback;
    const [index, conditionValue, mp] = sel;
    const child = mp.children;
    const fn = typeof child === "function" && child.length > 0;
    return fn ? untrack(() => child(mp.keyed ? conditionValue() : () => {
      if (untrack(switchFunc)()?.[0] !== index) throw narrowedError("Match");
      return conditionValue();
    })) : child;
  }, undefined, undefined);
}
function Match(props) {
  return props;
}

const booleans = ["allowfullscreen", "async", "alpha",
"autofocus",
"autoplay", "checked", "controls", "default", "disabled", "formnovalidate", "hidden",
"indeterminate", "inert",
"ismap", "loop", "multiple", "muted", "nomodule", "novalidate", "open", "playsinline", "readonly", "required", "reversed", "seamless",
"selected", "adauctionheaders",
"browsingtopics",
"credentialless",
"defaultchecked", "defaultmuted", "defaultselected", "defer", "disablepictureinpicture", "disableremoteplayback", "preservespitch",
"shadowrootclonable", "shadowrootcustomelementregistry",
"shadowrootdelegatesfocus", "shadowrootserializable",
"sharedstoragewritable"
];
const Properties = /*#__PURE__*/new Set([
"className", "value",
"readOnly", "noValidate", "formNoValidate", "isMap", "noModule", "playsInline", "adAuctionHeaders",
"allowFullscreen", "browsingTopics",
"defaultChecked", "defaultMuted", "defaultSelected", "disablePictureInPicture", "disableRemotePlayback", "preservesPitch", "shadowRootClonable", "shadowRootCustomElementRegistry",
"shadowRootDelegatesFocus", "shadowRootSerializable",
"sharedStorageWritable",
...booleans]);
const ChildProperties = /*#__PURE__*/new Set(["innerHTML", "textContent", "innerText", "children"]);
const Aliases = /*#__PURE__*/Object.assign(Object.create(null), {
  className: "class",
  htmlFor: "for"
});
const PropAliases = /*#__PURE__*/Object.assign(Object.create(null), {
  class: "className",
  novalidate: {
    $: "noValidate",
    FORM: 1
  },
  formnovalidate: {
    $: "formNoValidate",
    BUTTON: 1,
    INPUT: 1
  },
  ismap: {
    $: "isMap",
    IMG: 1
  },
  nomodule: {
    $: "noModule",
    SCRIPT: 1
  },
  playsinline: {
    $: "playsInline",
    VIDEO: 1
  },
  readonly: {
    $: "readOnly",
    INPUT: 1,
    TEXTAREA: 1
  },
  adauctionheaders: {
    $: "adAuctionHeaders",
    IFRAME: 1
  },
  allowfullscreen: {
    $: "allowFullscreen",
    IFRAME: 1
  },
  browsingtopics: {
    $: "browsingTopics",
    IMG: 1
  },
  defaultchecked: {
    $: "defaultChecked",
    INPUT: 1
  },
  defaultmuted: {
    $: "defaultMuted",
    AUDIO: 1,
    VIDEO: 1
  },
  defaultselected: {
    $: "defaultSelected",
    OPTION: 1
  },
  disablepictureinpicture: {
    $: "disablePictureInPicture",
    VIDEO: 1
  },
  disableremoteplayback: {
    $: "disableRemotePlayback",
    AUDIO: 1,
    VIDEO: 1
  },
  preservespitch: {
    $: "preservesPitch",
    AUDIO: 1,
    VIDEO: 1
  },
  shadowrootclonable: {
    $: "shadowRootClonable",
    TEMPLATE: 1
  },
  shadowrootdelegatesfocus: {
    $: "shadowRootDelegatesFocus",
    TEMPLATE: 1
  },
  shadowrootserializable: {
    $: "shadowRootSerializable",
    TEMPLATE: 1
  },
  sharedstoragewritable: {
    $: "sharedStorageWritable",
    IFRAME: 1,
    IMG: 1
  }
});
function getPropAlias(prop, tagName) {
  const a = PropAliases[prop];
  return typeof a === "object" ? a[tagName] ? a["$"] : undefined : a;
}
const DelegatedEvents = /*#__PURE__*/new Set(["beforeinput", "click", "dblclick", "contextmenu", "focusin", "focusout", "input", "keydown", "keyup", "mousedown", "mousemove", "mouseout", "mouseover", "mouseup", "pointerdown", "pointermove", "pointerout", "pointerover", "pointerup", "touchend", "touchmove", "touchstart"]);
const SVGElements = /*#__PURE__*/new Set([
"altGlyph", "altGlyphDef", "altGlyphItem", "animate", "animateColor", "animateMotion", "animateTransform", "circle", "clipPath", "color-profile", "cursor", "defs", "desc", "ellipse", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence", "filter", "font", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignObject", "g", "glyph", "glyphRef", "hkern", "image", "line", "linearGradient", "marker", "mask", "metadata", "missing-glyph", "mpath", "path", "pattern", "polygon", "polyline", "radialGradient", "rect",
"set", "stop",
"svg", "switch", "symbol", "text", "textPath",
"tref", "tspan", "use", "view", "vkern"]);
const SVGNamespace = {
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace"
};

const memo = fn => createMemo(() => fn());

function reconcileArrays(parentNode, a, b) {
  let bLength = b.length,
    aEnd = a.length,
    bEnd = bLength,
    aStart = 0,
    bStart = 0,
    after = a[aEnd - 1].nextSibling,
    map = null;
  while (aStart < aEnd || bStart < bEnd) {
    if (a[aStart] === b[bStart]) {
      aStart++;
      bStart++;
      continue;
    }
    while (a[aEnd - 1] === b[bEnd - 1]) {
      aEnd--;
      bEnd--;
    }
    if (aEnd === aStart) {
      const node = bEnd < bLength ? bStart ? b[bStart - 1].nextSibling : b[bEnd - bStart] : after;
      while (bStart < bEnd) parentNode.insertBefore(b[bStart++], node);
    } else if (bEnd === bStart) {
      while (aStart < aEnd) {
        if (!map || !map.has(a[aStart])) a[aStart].remove();
        aStart++;
      }
    } else if (a[aStart] === b[bEnd - 1] && b[bStart] === a[aEnd - 1]) {
      const node = a[--aEnd].nextSibling;
      parentNode.insertBefore(b[bStart++], a[aStart++].nextSibling);
      parentNode.insertBefore(b[--bEnd], node);
      a[aEnd] = b[bEnd];
    } else {
      if (!map) {
        map = new Map();
        let i = bStart;
        while (i < bEnd) map.set(b[i], i++);
      }
      const index = map.get(a[aStart]);
      if (index != null) {
        if (bStart < index && index < bEnd) {
          let i = aStart,
            sequence = 1,
            t;
          while (++i < aEnd && i < bEnd) {
            if ((t = map.get(a[i])) == null || t !== index + sequence) break;
            sequence++;
          }
          if (sequence > index - bStart) {
            const node = a[aStart];
            while (bStart < index) parentNode.insertBefore(b[bStart++], node);
          } else parentNode.replaceChild(b[bStart++], a[aStart++]);
        } else aStart++;
      } else a[aStart++].remove();
    }
  }
}

const $$EVENTS = "_$DX_DELEGATE";
function render(code, element, init, options = {}) {
  let disposer;
  createRoot(dispose => {
    disposer = dispose;
    element === document ? code() : insert(element, code(), element.firstChild ? null : undefined, init);
  }, options.owner);
  return () => {
    disposer();
    element.textContent = "";
  };
}
function template(html, isImportNode, isSVG, isMathML) {
  let node;
  const create = () => {
    const t = isMathML ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
    t.innerHTML = html;
    return isSVG ? t.content.firstChild.firstChild : isMathML ? t.firstChild : t.content.firstChild;
  };
  const fn = isImportNode ? () => untrack(() => document.importNode(node || (node = create()), true)) : () => (node || (node = create())).cloneNode(true);
  fn.cloneNode = fn;
  return fn;
}
function delegateEvents(eventNames, document = window.document) {
  const e = document[$$EVENTS] || (document[$$EVENTS] = new Set());
  for (let i = 0, l = eventNames.length; i < l; i++) {
    const name = eventNames[i];
    if (!e.has(name)) {
      e.add(name);
      document.addEventListener(name, eventHandler);
    }
  }
}
function setAttribute(node, name, value) {
  if (value == null) node.removeAttribute(name);else node.setAttribute(name, value);
}
function setAttributeNS(node, namespace, name, value) {
  if (value == null) node.removeAttributeNS(namespace, name);else node.setAttributeNS(namespace, name, value);
}
function setBoolAttribute(node, name, value) {
  value ? node.setAttribute(name, "") : node.removeAttribute(name);
}
function className(node, value) {
  if (value == null) node.removeAttribute("class");else node.className = value;
}
function addEventListener(node, name, handler, delegate) {
  if (delegate) {
    if (Array.isArray(handler)) {
      node[`$$${name}`] = handler[0];
      node[`$$${name}Data`] = handler[1];
    } else node[`$$${name}`] = handler;
  } else if (Array.isArray(handler)) {
    const handlerFn = handler[0];
    node.addEventListener(name, handler[0] = e => handlerFn.call(node, handler[1], e));
  } else node.addEventListener(name, handler, typeof handler !== "function" && handler);
}
function classList(node, value, prev = {}) {
  const classKeys = Object.keys(value || {}),
    prevKeys = Object.keys(prev);
  let i, len;
  for (i = 0, len = prevKeys.length; i < len; i++) {
    const key = prevKeys[i];
    if (!key || key === "undefined" || value[key]) continue;
    toggleClassKey(node, key, false);
    delete prev[key];
  }
  for (i = 0, len = classKeys.length; i < len; i++) {
    const key = classKeys[i],
      classValue = !!value[key];
    if (!key || key === "undefined" || prev[key] === classValue || !classValue) continue;
    toggleClassKey(node, key, true);
    prev[key] = classValue;
  }
  return prev;
}
function style(node, value, prev) {
  if (!value) return prev ? setAttribute(node, "style") : value;
  const nodeStyle = node.style;
  if (typeof value === "string") return nodeStyle.cssText = value;
  typeof prev === "string" && (nodeStyle.cssText = prev = undefined);
  prev || (prev = {});
  value || (value = {});
  let v, s;
  for (s in prev) {
    value[s] == null && nodeStyle.removeProperty(s);
    delete prev[s];
  }
  for (s in value) {
    v = value[s];
    if (v !== prev[s]) {
      nodeStyle.setProperty(s, v);
      prev[s] = v;
    }
  }
  return prev;
}
function setStyleProperty(node, name, value) {
  value != null ? node.style.setProperty(name, value) : node.style.removeProperty(name);
}
function spread(node, props = {}, isSVG, skipChildren) {
  const prevProps = {};
  if (!skipChildren) {
    createRenderEffect(() => prevProps.children = insertExpression(node, props.children, prevProps.children));
  }
  createRenderEffect(() => typeof props.ref === "function" && use(props.ref, node));
  createRenderEffect(() => assign(node, props, isSVG, true, prevProps, true));
  return prevProps;
}
function use(fn, element, arg) {
  return untrack(() => fn(element, arg));
}
function insert(parent, accessor, marker, initial) {
  if (marker !== undefined && !initial) initial = [];
  if (typeof accessor !== "function") return insertExpression(parent, accessor, initial, marker);
  createRenderEffect(current => insertExpression(parent, accessor(), current, marker), initial);
}
function assign(node, props, isSVG, skipChildren, prevProps = {}, skipRef = false) {
  props || (props = {});
  for (const prop in prevProps) {
    if (!(prop in props)) {
      if (prop === "children") continue;
      prevProps[prop] = assignProp(node, prop, null, prevProps[prop], isSVG, skipRef, props);
    }
  }
  for (const prop in props) {
    if (prop === "children") {
      continue;
    }
    const value = props[prop];
    prevProps[prop] = assignProp(node, prop, value, prevProps[prop], isSVG, skipRef, props);
  }
}
function toPropertyName(name) {
  return name.toLowerCase().replace(/-([a-z])/g, (_, w) => w.toUpperCase());
}
function toggleClassKey(node, key, value) {
  const classNames = key.trim().split(/\s+/);
  for (let i = 0, nameLen = classNames.length; i < nameLen; i++) node.classList.toggle(classNames[i], value);
}
function assignProp(node, prop, value, prev, isSVG, skipRef, props) {
  let isCE, isProp, isChildProp, propAlias, forceProp;
  if (prop === "style") return style(node, value, prev);
  if (prop === "classList") return classList(node, value, prev);
  if (value === prev) return prev;
  if (prop === "ref") {
    if (!skipRef) value(node);
  } else if (prop.slice(0, 3) === "on:") {
    const e = prop.slice(3);
    prev && node.removeEventListener(e, prev, typeof prev !== "function" && prev);
    value && node.addEventListener(e, value, typeof value !== "function" && value);
  } else if (prop.slice(0, 10) === "oncapture:") {
    const e = prop.slice(10);
    prev && node.removeEventListener(e, prev, true);
    value && node.addEventListener(e, value, true);
  } else if (prop.slice(0, 2) === "on") {
    const name = prop.slice(2).toLowerCase();
    const delegate = DelegatedEvents.has(name);
    if (!delegate && prev) {
      const h = Array.isArray(prev) ? prev[0] : prev;
      node.removeEventListener(name, h);
    }
    if (delegate || value) {
      addEventListener(node, name, value, delegate);
      delegate && delegateEvents([name]);
    }
  } else if (prop.slice(0, 5) === "attr:") {
    setAttribute(node, prop.slice(5), value);
  } else if (prop.slice(0, 5) === "bool:") {
    setBoolAttribute(node, prop.slice(5), value);
  } else if ((forceProp = prop.slice(0, 5) === "prop:") || (isChildProp = ChildProperties.has(prop)) || !isSVG && ((propAlias = getPropAlias(prop, node.tagName)) || (isProp = Properties.has(prop))) || (isCE = node.nodeName.includes("-") || "is" in props)) {
    if (forceProp) {
      prop = prop.slice(5);
      isProp = true;
    }
    if (prop === "class" || prop === "className") className(node, value);else if (isCE && !isProp && !isChildProp) node[toPropertyName(prop)] = value;else node[propAlias || prop] = value;
  } else {
    const ns = isSVG && prop.indexOf(":") > -1 && SVGNamespace[prop.split(":")[0]];
    if (ns) setAttributeNS(node, ns, prop, value);else setAttribute(node, Aliases[prop] || prop, value);
  }
  return value;
}
function eventHandler(e) {
  let node = e.target;
  const key = `$$${e.type}`;
  const oriTarget = e.target;
  const oriCurrentTarget = e.currentTarget;
  const retarget = value => Object.defineProperty(e, "target", {
    configurable: true,
    value
  });
  const handleNode = () => {
    const handler = node[key];
    if (handler && !node.disabled) {
      const data = node[`${key}Data`];
      data !== undefined ? handler.call(node, data, e) : handler.call(node, e);
      if (e.cancelBubble) return;
    }
    node.host && typeof node.host !== "string" && !node.host._$host && node.contains(e.target) && retarget(node.host);
    return true;
  };
  const walkUpTree = () => {
    while (handleNode() && (node = node._$host || node.parentNode || node.host));
  };
  Object.defineProperty(e, "currentTarget", {
    configurable: true,
    get() {
      return node || document;
    }
  });
  if (e.composedPath) {
    const path = e.composedPath();
    retarget(path[0]);
    for (let i = 0; i < path.length - 2; i++) {
      node = path[i];
      if (!handleNode()) break;
      if (node._$host) {
        node = node._$host;
        walkUpTree();
        break;
      }
      if (node.parentNode === oriCurrentTarget) {
        break;
      }
    }
  }
  else walkUpTree();
  retarget(oriTarget);
}
function insertExpression(parent, value, current, marker, unwrapArray) {
  while (typeof current === "function") current = current();
  if (value === current) return current;
  const t = typeof value,
    multi = marker !== undefined;
  parent = multi && current[0] && current[0].parentNode || parent;
  if (t === "string" || t === "number") {
    if (t === "number") {
      value = value.toString();
      if (value === current) return current;
    }
    if (multi) {
      let node = current[0];
      if (node && node.nodeType === 3) {
        node.data !== value && (node.data = value);
      } else node = document.createTextNode(value);
      current = cleanChildren(parent, current, marker, node);
    } else {
      if (current !== "" && typeof current === "string") {
        current = parent.firstChild.data = value;
      } else current = parent.textContent = value;
    }
  } else if (value == null || t === "boolean") {
    current = cleanChildren(parent, current, marker);
  } else if (t === "function") {
    createRenderEffect(() => {
      let v = value();
      while (typeof v === "function") v = v();
      current = insertExpression(parent, v, current, marker);
    });
    return () => current;
  } else if (Array.isArray(value)) {
    const array = [];
    const currentArray = current && Array.isArray(current);
    if (normalizeIncomingArray(array, value, current, unwrapArray)) {
      createRenderEffect(() => current = insertExpression(parent, array, current, marker, true));
      return () => current;
    }
    if (array.length === 0) {
      current = cleanChildren(parent, current, marker);
      if (multi) return current;
    } else if (currentArray) {
      if (current.length === 0) {
        appendNodes(parent, array, marker);
      } else reconcileArrays(parent, current, array);
    } else {
      current && cleanChildren(parent);
      appendNodes(parent, array);
    }
    current = array;
  } else if (value.nodeType) {
    if (Array.isArray(current)) {
      if (multi) return current = cleanChildren(parent, current, marker, value);
      cleanChildren(parent, current, null, value);
    } else if (current == null || current === "" || !parent.firstChild) {
      parent.appendChild(value);
    } else parent.replaceChild(value, parent.firstChild);
    current = value;
  } else ;
  return current;
}
function normalizeIncomingArray(normalized, array, current, unwrap) {
  let dynamic = false;
  for (let i = 0, len = array.length; i < len; i++) {
    let item = array[i],
      prev = current && current[normalized.length],
      t;
    if (item == null || item === true || item === false) ; else if ((t = typeof item) === "object" && item.nodeType) {
      normalized.push(item);
    } else if (Array.isArray(item)) {
      dynamic = normalizeIncomingArray(normalized, item, prev) || dynamic;
    } else if (t === "function") {
      if (unwrap) {
        while (typeof item === "function") item = item();
        dynamic = normalizeIncomingArray(normalized, Array.isArray(item) ? item : [item], Array.isArray(prev) ? prev : [prev]) || dynamic;
      } else {
        normalized.push(item);
        dynamic = true;
      }
    } else {
      const value = String(item);
      if (prev && prev.nodeType === 3 && prev.data === value) normalized.push(prev);else normalized.push(document.createTextNode(value));
    }
  }
  return dynamic;
}
function appendNodes(parent, array, marker = null) {
  for (let i = 0, len = array.length; i < len; i++) parent.insertBefore(array[i], marker);
}
function cleanChildren(parent, current, marker, replacement) {
  if (marker === undefined) return parent.textContent = "";
  const node = replacement || document.createTextNode("");
  if (current.length) {
    let inserted = false;
    for (let i = current.length - 1; i >= 0; i--) {
      const el = current[i];
      if (node !== el) {
        const isParent = el.parentNode === parent;
        if (!inserted && !i) isParent ? parent.replaceChild(node, el) : parent.insertBefore(node, marker);else isParent && el.remove();
      } else inserted = true;
    }
  } else parent.insertBefore(node, marker);
  return [node];
}
const voidFn = () => undefined;

const isServer = false;
const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
function createElement(tagName, isSVG = false, is = undefined) {
  return isSVG ? document.createElementNS(SVG_NAMESPACE, tagName) : document.createElement(tagName, {
    is
  });
}
function createDynamic(component, props) {
  const cached = createMemo(component);
  return createMemo(() => {
    const component = cached();
    switch (typeof component) {
      case "function":
        return untrack(() => component(props));
      case "string":
        const isSvg = SVGElements.has(component);
        const el = createElement(component, isSvg, untrack(() => props.is));
        spread(el, props, isSvg);
        return el;
    }
  });
}
function Dynamic(props) {
  const [, others] = splitProps(props, ["component"]);
  return createDynamic(() => props.component, others);
}

function createBeforeLeave() {
    let listeners = new Set();
    function subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
    }
    let ignore = false;
    function confirm(to, options) {
        if (ignore)
            return !(ignore = false);
        const e = {
            to,
            options,
            defaultPrevented: false,
            preventDefault: () => (e.defaultPrevented = true)
        };
        for (const l of listeners)
            l.listener({
                ...e,
                from: l.location,
                retry: (force) => {
                    force && (ignore = true);
                    l.navigate(to, { ...options, resolve: false });
                }
            });
        return !e.defaultPrevented;
    }
    return {
        subscribe,
        confirm
    };
}
// The following supports browser initiated blocking (eg back/forward)
let depth;
function saveCurrentDepth() {
    if (!window.history.state || window.history.state._depth == null) {
        window.history.replaceState({ ...window.history.state, _depth: window.history.length - 1 }, "");
    }
    depth = window.history.state._depth;
}
{
    saveCurrentDepth();
}
function keepDepth(state) {
    return {
        ...state,
        _depth: window.history.state && window.history.state._depth
    };
}
function notifyIfNotBlocked(notify, block) {
    let ignore = false;
    return () => {
        const prevDepth = depth;
        saveCurrentDepth();
        const delta = prevDepth == null ? null : depth - prevDepth;
        if (ignore) {
            ignore = false;
            return;
        }
        if (delta && block(delta)) {
            ignore = true;
            window.history.go(-delta);
        }
        else {
            notify();
        }
    };
}

const hasSchemeRegex = /^(?:[a-z0-9]+:)?\/\//i;
const trimPathRegex = /^\/+|(\/)\/+$/g;
const mockBase = "http://sr";
function normalizePath(path, omitSlash = false) {
    const s = path.replace(trimPathRegex, "$1");
    return s ? (omitSlash || /^[?#]/.test(s) ? s : "/" + s) : "";
}
function resolvePath(base, path, from) {
    if (hasSchemeRegex.test(path)) {
        return undefined;
    }
    const basePath = normalizePath(base);
    const fromPath = from && normalizePath(from);
    let result = "";
    if (!fromPath || path.startsWith("/")) {
        result = basePath;
    }
    else if (fromPath.toLowerCase().indexOf(basePath.toLowerCase()) !== 0) {
        result = basePath + fromPath;
    }
    else {
        result = fromPath;
    }
    return (result || "/") + normalizePath(path, !result);
}
function invariant(value, message) {
    if (value == null) {
        throw new Error(message);
    }
    return value;
}
function joinPaths(from, to) {
    return normalizePath(from).replace(/\/*(\*.*)?$/g, "") + normalizePath(to);
}
function extractSearchParams(url) {
    const params = {};
    url.searchParams.forEach((value, key) => {
        if (key in params) {
            if (Array.isArray(params[key]))
                params[key].push(value);
            else
                params[key] = [params[key], value];
        }
        else
            params[key] = value;
    });
    return params;
}
function createMatcher(path, partial, matchFilters) {
    const [pattern, splat] = path.split("/*", 2);
    const segments = pattern.split("/").filter(Boolean);
    const len = segments.length;
    return (location) => {
        const locSegments = location.split("/").filter(Boolean);
        const lenDiff = locSegments.length - len;
        if (lenDiff < 0 || (lenDiff > 0 && splat === undefined && !partial)) {
            return null;
        }
        const match = {
            path: len ? "" : "/",
            params: {}
        };
        const matchFilter = (s) => matchFilters === undefined ? undefined : matchFilters[s];
        for (let i = 0; i < len; i++) {
            const segment = segments[i];
            const dynamic = segment[0] === ":";
            const locSegment = dynamic ? locSegments[i] : locSegments[i].toLowerCase();
            const key = dynamic ? segment.slice(1) : segment.toLowerCase();
            if (dynamic && matchSegment(locSegment, matchFilter(key))) {
                match.params[key] = locSegment;
            }
            else if (dynamic || !matchSegment(locSegment, key)) {
                return null;
            }
            match.path += `/${locSegment}`;
        }
        if (splat) {
            const remainder = lenDiff ? locSegments.slice(-lenDiff).join("/") : "";
            if (matchSegment(remainder, matchFilter(splat))) {
                match.params[splat] = remainder;
            }
            else {
                return null;
            }
        }
        return match;
    };
}
function matchSegment(input, filter) {
    const isEqual = (s) => s === input;
    if (filter === undefined) {
        return true;
    }
    else if (typeof filter === "string") {
        return isEqual(filter);
    }
    else if (typeof filter === "function") {
        return filter(input);
    }
    else if (Array.isArray(filter)) {
        return filter.some(isEqual);
    }
    else if (filter instanceof RegExp) {
        return filter.test(input);
    }
    return false;
}
function scoreRoute(route) {
    const [pattern, splat] = route.pattern.split("/*", 2);
    const segments = pattern.split("/").filter(Boolean);
    return segments.reduce((score, segment) => score + (segment.startsWith(":") ? 2 : 3), segments.length - (splat === undefined ? 0 : 1));
}
function createMemoObject(fn) {
    const map = new Map();
    const owner = getOwner();
    return new Proxy({}, {
        get(_, property) {
            if (!map.has(property)) {
                runWithOwner(owner, () => map.set(property, createMemo(() => fn()[property])));
            }
            return map.get(property)();
        },
        getOwnPropertyDescriptor() {
            return {
                enumerable: true,
                configurable: true
            };
        },
        ownKeys() {
            return Reflect.ownKeys(fn());
        },
        has(_, property) {
            return property in fn();
        }
    });
}
function mergeSearchString(search, params) {
    const merged = new URLSearchParams(search);
    Object.entries(params).forEach(([key, value]) => {
        if (value == null || value === "" || (value instanceof Array && !value.length)) {
            merged.delete(key);
        }
        else {
            if (value instanceof Array) {
                // Delete all instances of the key before appending
                merged.delete(key);
                value.forEach(v => {
                    merged.append(key, String(v));
                });
            }
            else {
                merged.set(key, String(value));
            }
        }
    });
    const s = merged.toString();
    return s ? `?${s}` : "";
}
function expandOptionals(pattern) {
    let match = /(\/?\:[^\/]+)\?/.exec(pattern);
    if (!match)
        return [pattern];
    let prefix = pattern.slice(0, match.index);
    let suffix = pattern.slice(match.index + match[0].length);
    const prefixes = [prefix, (prefix += match[1])];
    // This section handles adjacent optional params. We don't actually want all permuations since
    // that will lead to equivalent routes which have the same number of params. For example
    // `/:a?/:b?/:c`? only has the unique expansion: `/`, `/:a`, `/:a/:b`, `/:a/:b/:c` and we can
    // discard `/:b`, `/:c`, `/:b/:c` by building them up in order and not recursing. This also helps
    // ensure predictability where earlier params have precidence.
    while ((match = /^(\/\:[^\/]+)\?/.exec(suffix))) {
        prefixes.push((prefix += match[1]));
        suffix = suffix.slice(match[0].length);
    }
    return expandOptionals(suffix).reduce((results, expansion) => [...results, ...prefixes.map(p => p + expansion)], []);
}

const MAX_REDIRECTS = 100;
const RouterContextObj = createContext();
const RouteContextObj = createContext();
const useRouter = () => invariant(useContext(RouterContextObj), "<A> and 'use' router primitives can be only used inside a Route.");
/**
 * Retrieves method to do navigation. The method accepts a path to navigate to and an optional object with the following options:
 *
 * - resolve (*boolean*, default `true`): resolve the path against the current route
 * - replace (*boolean*, default `false`): replace the history entry
 * - scroll (*boolean*, default `true`): scroll to top after navigation
 * - state (*any*, default `undefined`): pass custom state to `location.state`
 *
 * **Note**: The state is serialized using the structured clone algorithm which does not support all object types.
 *
 * @example
 * ```js
 * const navigate = useNavigate();
 *
 * if (unauthorized) {
 *   navigate("/login", { replace: true });
 * }
 * ```
 */
const useNavigate = () => useRouter().navigatorFactory();
/**
 * Retrieves reactive `location` object useful for getting things like `pathname`.
 *
 * @example
 * ```js
 * const location = useLocation();
 *
 * const pathname = createMemo(() => parsePath(location.pathname));
 * ```
 */
const useLocation = () => useRouter().location;
/**
 * Retrieves a tuple containing a reactive object to read the current location's query parameters and a method to update them.
 * The object is a proxy so you must access properties to subscribe to reactive updates.
 * **Note** that values will be strings and property names will retain their casing.
 *
 * The setter method accepts an object whose entries will be merged into the current query string.
 * Values `''`, `undefined` and `null` will remove the key from the resulting query string.
 * Updates will behave just like a navigation and the setter accepts the same optional second parameter as `navigate` and auto-scrolling is disabled by default.
 *
 * @examples
 * ```js
 * const [searchParams, setSearchParams] = useSearchParams();
 *
 * return (
 *   <div>
 *     <span>Page: {searchParams.page}</span>
 *     <button
 *       onClick={() =>
 *         setSearchParams({ page: (parseInt(searchParams.page) || 0) + 1 })
 *       }
 *     >
 *       Next Page
 *     </button>
 *   </div>
 * );
 * ```
 */
const useSearchParams = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const setSearchParams = (params, options) => {
        const searchString = untrack(() => mergeSearchString(location.search, params) + location.hash);
        navigate(searchString, {
            scroll: false,
            resolve: false,
            ...options
        });
    };
    return [location.query, setSearchParams];
};
function createRoutes(routeDef, base = "") {
    const { component, preload, load, children, info } = routeDef;
    const isLeaf = !children || (Array.isArray(children) && !children.length);
    const shared = {
        key: routeDef,
        component,
        preload: preload || load,
        info
    };
    return asArray$1(routeDef.path).reduce((acc, originalPath) => {
        for (const expandedPath of expandOptionals(originalPath)) {
            const path = joinPaths(base, expandedPath);
            let pattern = isLeaf ? path : path.split("/*", 1)[0];
            pattern = pattern
                .split("/")
                .map((s) => {
                return s.startsWith(":") || s.startsWith("*") ? s : encodeURIComponent(s);
            })
                .join("/");
            acc.push({
                ...shared,
                originalPath,
                pattern,
                matcher: createMatcher(pattern, !isLeaf, routeDef.matchFilters)
            });
        }
        return acc;
    }, []);
}
function createBranch(routes, index = 0) {
    return {
        routes,
        score: scoreRoute(routes[routes.length - 1]) * 10000 - index,
        matcher(location) {
            const matches = [];
            for (let i = routes.length - 1; i >= 0; i--) {
                const route = routes[i];
                const match = route.matcher(location);
                if (!match) {
                    return null;
                }
                matches.unshift({
                    ...match,
                    route
                });
            }
            return matches;
        }
    };
}
function asArray$1(value) {
    return Array.isArray(value) ? value : [value];
}
function createBranches(routeDef, base = "", stack = [], branches = []) {
    const routeDefs = asArray$1(routeDef);
    for (let i = 0, len = routeDefs.length; i < len; i++) {
        const def = routeDefs[i];
        if (def && typeof def === "object") {
            if (!def.hasOwnProperty("path"))
                def.path = "";
            const routes = createRoutes(def, base);
            for (const route of routes) {
                stack.push(route);
                const isEmptyArray = Array.isArray(def.children) && def.children.length === 0;
                if (def.children && !isEmptyArray) {
                    createBranches(def.children, route.pattern, stack, branches);
                }
                else {
                    const branch = createBranch([...stack], branches.length);
                    branches.push(branch);
                }
                stack.pop();
            }
        }
    }
    // Stack will be empty on final return
    return stack.length ? branches : branches.sort((a, b) => b.score - a.score);
}
function getRouteMatches(branches, location) {
    for (let i = 0, len = branches.length; i < len; i++) {
        const match = branches[i].matcher(location);
        if (match) {
            return match;
        }
    }
    return [];
}
function createLocation(path, state, queryWrapper) {
    const origin = new URL(mockBase);
    const url = createMemo(prev => {
        const path_ = path();
        try {
            return new URL(path_, origin);
        }
        catch (err) {
            console.error(`Invalid path ${path_}`);
            return prev;
        }
    }, origin, {
        equals: (a, b) => a.href === b.href
    });
    const pathname = createMemo(() => url().pathname);
    const search = createMemo(() => url().search, true);
    const hash = createMemo(() => url().hash);
    const key = () => "";
    const queryFn = on(search, () => extractSearchParams(url()));
    return {
        get pathname() {
            return pathname();
        },
        get search() {
            return search();
        },
        get hash() {
            return hash();
        },
        get state() {
            return state();
        },
        get key() {
            return key();
        },
        query: queryWrapper ? queryWrapper(queryFn) : createMemoObject(queryFn)
    };
}
let intent;
function getIntent() {
    return intent;
}
function setInPreloadFn(value) {
}
function createRouterContext(integration, branches, getContext, options = {}) {
    const { signal: [source, setSource], utils = {} } = integration;
    const parsePath = utils.parsePath || (p => p);
    const renderPath = utils.renderPath || (p => p);
    const beforeLeave = utils.beforeLeave || createBeforeLeave();
    const basePath = resolvePath("", options.base || "");
    if (basePath === undefined) {
        throw new Error(`${basePath} is not a valid base path`);
    }
    else if (basePath && !source().value) {
        setSource({ value: basePath, replace: true, scroll: false });
    }
    const [isRouting, setIsRouting] = createSignal(false);
    // Keep track of last target, so that last call to transition wins
    let lastTransitionTarget;
    // Transition the location to a new value
    const transition = (newIntent, newTarget) => {
        if (newTarget.value === reference() && newTarget.state === state())
            return;
        if (lastTransitionTarget === undefined)
            setIsRouting(true);
        intent = newIntent;
        lastTransitionTarget = newTarget;
        startTransition(() => {
            if (lastTransitionTarget !== newTarget)
                return;
            setReference(lastTransitionTarget.value);
            setState(lastTransitionTarget.state);
            submissions[1](subs => subs.filter(s => s.pending));
        }).finally(() => {
            if (lastTransitionTarget !== newTarget)
                return;
            // Batch, in order for isRouting and final source update to happen together
            batch(() => {
                intent = undefined;
                if (newIntent === "navigate")
                    navigateEnd(lastTransitionTarget);
                setIsRouting(false);
                lastTransitionTarget = undefined;
            });
        });
    };
    const [reference, setReference] = createSignal(source().value);
    const [state, setState] = createSignal(source().state);
    const location = createLocation(reference, state, utils.queryWrapper);
    const referrers = [];
    const submissions = createSignal([]);
    const matches = createMemo(() => {
        if (typeof options.transformUrl === "function") {
            return getRouteMatches(branches(), options.transformUrl(location.pathname));
        }
        return getRouteMatches(branches(), location.pathname);
    });
    const buildParams = () => {
        const m = matches();
        const params = {};
        for (let i = 0; i < m.length; i++) {
            Object.assign(params, m[i].params);
        }
        return params;
    };
    const params = utils.paramsWrapper
        ? utils.paramsWrapper(buildParams, branches)
        : createMemoObject(buildParams);
    const baseRoute = {
        pattern: basePath,
        path: () => basePath,
        outlet: () => null,
        resolvePath(to) {
            return resolvePath(basePath, to);
        }
    };
    // Create a native transition, when source updates
    createRenderEffect(on(source, source => transition("native", source), { defer: true }));
    return {
        base: baseRoute,
        location,
        params,
        isRouting,
        renderPath,
        parsePath,
        navigatorFactory,
        matches,
        beforeLeave,
        preloadRoute,
        singleFlight: options.singleFlight === undefined ? true : options.singleFlight,
        submissions
    };
    function navigateFromRoute(route, to, options) {
        // Untrack in case someone navigates in an effect - don't want to track `reference` or route paths
        untrack(() => {
            if (typeof to === "number") {
                if (!to) {
                    // A delta of 0 means stay at the current location, so it is ignored
                }
                else if (utils.go) {
                    utils.go(to);
                }
                else {
                    console.warn("Router integration does not support relative routing");
                }
                return;
            }
            const queryOnly = !to || to[0] === "?";
            const { replace, resolve, scroll, state: nextState } = {
                replace: false,
                resolve: !queryOnly,
                scroll: true,
                ...options
            };
            const resolvedTo = resolve
                ? route.resolvePath(to)
                : resolvePath((queryOnly && location.pathname) || "", to);
            if (resolvedTo === undefined) {
                throw new Error(`Path '${to}' is not a routable path`);
            }
            else if (referrers.length >= MAX_REDIRECTS) {
                throw new Error("Too many redirects");
            }
            const current = reference();
            if (resolvedTo !== current || nextState !== state()) {
                if (isServer) ;
                else if (beforeLeave.confirm(resolvedTo, options)) {
                    referrers.push({ value: current, replace, scroll, state: state() });
                    transition("navigate", {
                        value: resolvedTo,
                        state: nextState
                    });
                }
            }
        });
    }
    function navigatorFactory(route) {
        // Workaround for vite issue (https://github.com/vitejs/vite/issues/3803)
        route = route || useContext(RouteContextObj) || baseRoute;
        return (to, options) => navigateFromRoute(route, to, options);
    }
    function navigateEnd(next) {
        const first = referrers[0];
        if (first) {
            setSource({
                ...next,
                replace: first.replace,
                scroll: first.scroll
            });
            referrers.length = 0;
        }
    }
    function preloadRoute(url, preloadData) {
        const matches = getRouteMatches(branches(), url.pathname);
        const prevIntent = intent;
        intent = "preload";
        for (let match in matches) {
            const { route, params } = matches[match];
            route.component &&
                route.component.preload &&
                route.component.preload();
            const { preload } = route;
            preloadData &&
                preload &&
                runWithOwner(getContext(), () => preload({
                    params,
                    location: {
                        pathname: url.pathname,
                        search: url.search,
                        hash: url.hash,
                        query: extractSearchParams(url),
                        state: null,
                        key: ""
                    },
                    intent: "preload"
                }));
        }
        intent = prevIntent;
    }
}
function createRouteContext(router, parent, outlet, match) {
    const { base, location, params } = router;
    const { pattern, component, preload } = match().route;
    const path = createMemo(() => match().path);
    component &&
        component.preload &&
        component.preload();
    const data = preload ? preload({ params, location, intent: intent || "initial" }) : undefined;
    const route = {
        parent,
        pattern,
        path,
        outlet: () => component
            ? createComponent(component, {
                params,
                location,
                data,
                get children() {
                    return outlet();
                }
            })
            : outlet(),
        resolvePath(to) {
            return resolvePath(base.path(), to, path());
        }
    };
    return route;
}

const createRouterComponent = (router) => (props) => {
  const {
    base
  } = props;
  const routeDefs = children(() => props.children);
  const branches = createMemo(() => createBranches(routeDefs(), props.base || ""));
  let context;
  const routerState = createRouterContext(router, branches, () => context, {
    base,
    singleFlight: props.singleFlight,
    transformUrl: props.transformUrl
  });
  router.create && router.create(routerState);
  return createComponent(RouterContextObj.Provider, {
    value: routerState,
    get children() {
      return createComponent(Root$1, {
        routerState,
        get root() {
          return props.root;
        },
        get preload() {
          return props.rootPreload || props.rootLoad;
        },
        get children() {
          return [memo(() => (context = getOwner()) && null), createComponent(Routes, {
            routerState,
            get branches() {
              return branches();
            }
          })];
        }
      });
    }
  });
};
function Root$1(props) {
  const location = props.routerState.location;
  const params = props.routerState.params;
  const data = createMemo(() => props.preload && untrack(() => {
    setInPreloadFn(true);
    props.preload({
      params,
      location,
      intent: getIntent() || "initial"
    });
    setInPreloadFn(false);
  }));
  return createComponent(Show, {
    get when() {
      return props.root;
    },
    keyed: true,
    get fallback() {
      return props.children;
    },
    children: (Root2) => createComponent(Root2, {
      params,
      location,
      get data() {
        return data();
      },
      get children() {
        return props.children;
      }
    })
  });
}
function Routes(props) {
  const disposers = [];
  let root;
  const routeStates = createMemo(on(props.routerState.matches, (nextMatches, prevMatches, prev) => {
    let equal = prevMatches && nextMatches.length === prevMatches.length;
    const next = [];
    for (let i = 0, len = nextMatches.length; i < len; i++) {
      const prevMatch = prevMatches && prevMatches[i];
      const nextMatch = nextMatches[i];
      if (prev && prevMatch && nextMatch.route.key === prevMatch.route.key) {
        next[i] = prev[i];
      } else {
        equal = false;
        if (disposers[i]) {
          disposers[i]();
        }
        createRoot((dispose) => {
          disposers[i] = dispose;
          next[i] = createRouteContext(props.routerState, next[i - 1] || props.routerState.base, createOutlet(() => routeStates()[i + 1]), () => {
            const routeMatches = props.routerState.matches();
            return routeMatches[i] ?? routeMatches[0];
          });
        });
      }
    }
    disposers.splice(nextMatches.length).forEach((dispose) => dispose());
    if (prev && equal) {
      return prev;
    }
    root = next[0];
    return next;
  }));
  return createOutlet(() => routeStates() && root)();
}
const createOutlet = (child) => {
  return () => createComponent(Show, {
    get when() {
      return child();
    },
    keyed: true,
    children: (child2) => createComponent(RouteContextObj.Provider, {
      value: child2,
      get children() {
        return child2.outlet();
      }
    })
  });
};
const Route = (props) => {
  const childRoutes = children(() => props.children);
  return mergeProps(props, {
    get children() {
      return childRoutes();
    }
  });
};

function intercept([value, setValue], get, set) {
    return [value, set ? (v) => setValue(set(v)) : setValue];
}
function createRouter(config) {
    let ignore = false;
    const wrap = (value) => (typeof value === "string" ? { value } : value);
    const signal = intercept(createSignal(wrap(config.get()), {
        equals: (a, b) => a.value === b.value && a.state === b.state
    }), undefined, next => {
        !ignore && config.set(next);
        return next;
    });
    config.init &&
        onCleanup(config.init((value = config.get()) => {
            ignore = true;
            signal[1](wrap(value));
            ignore = false;
        }));
    return createRouterComponent({
        signal,
        create: config.create,
        utils: config.utils
    });
}
function bindEvent(target, type, handler) {
    target.addEventListener(type, handler);
    return () => target.removeEventListener(type, handler);
}
function scrollToHash(hash, fallbackTop) {
    const el = hash && document.getElementById(hash);
    if (el) {
        el.scrollIntoView();
    }
    else if (fallbackTop) {
        window.scrollTo(0, 0);
    }
}

const actions = /* #__PURE__ */ new Map();

function setupNativeEvents(preload = true, explicitLinks = false, actionBase = "/_server", transformUrl) {
    return (router) => {
        const basePath = router.base.path();
        const navigateFromRoute = router.navigatorFactory(router.base);
        let preloadTimeout;
        let lastElement;
        function isSvg(el) {
            return el.namespaceURI === "http://www.w3.org/2000/svg";
        }
        function handleAnchor(evt) {
            if (evt.defaultPrevented ||
                evt.button !== 0 ||
                evt.metaKey ||
                evt.altKey ||
                evt.ctrlKey ||
                evt.shiftKey)
                return;
            const a = evt
                .composedPath()
                .find(el => el instanceof Node && el.nodeName.toUpperCase() === "A");
            if (!a || (explicitLinks && !a.hasAttribute("link")))
                return;
            const svg = isSvg(a);
            const href = svg ? a.href.baseVal : a.href;
            const target = svg ? a.target.baseVal : a.target;
            if (target || (!href && !a.hasAttribute("state")))
                return;
            const rel = (a.getAttribute("rel") || "").split(/\s+/);
            if (a.hasAttribute("download") || (rel && rel.includes("external")))
                return;
            const url = svg ? new URL(href, document.baseURI) : new URL(href);
            if (url.origin !== window.location.origin ||
                (basePath && url.pathname && !url.pathname.toLowerCase().startsWith(basePath.toLowerCase())))
                return;
            return [a, url];
        }
        function handleAnchorClick(evt) {
            const res = handleAnchor(evt);
            if (!res)
                return;
            const [a, url] = res;
            const to = router.parsePath(url.pathname + url.search + url.hash);
            const state = a.getAttribute("state");
            evt.preventDefault();
            navigateFromRoute(to, {
                resolve: false,
                replace: a.hasAttribute("replace"),
                scroll: !a.hasAttribute("noscroll"),
                state: state ? JSON.parse(state) : undefined
            });
        }
        function handleAnchorPreload(evt) {
            const res = handleAnchor(evt);
            if (!res)
                return;
            const [a, url] = res;
            transformUrl && (url.pathname = transformUrl(url.pathname));
            router.preloadRoute(url, a.getAttribute("preload") !== "false");
        }
        function handleAnchorMove(evt) {
            clearTimeout(preloadTimeout);
            const res = handleAnchor(evt);
            if (!res)
                return lastElement = null;
            const [a, url] = res;
            if (lastElement === a)
                return;
            transformUrl && (url.pathname = transformUrl(url.pathname));
            preloadTimeout = setTimeout(() => {
                router.preloadRoute(url, a.getAttribute("preload") !== "false");
                lastElement = a;
            }, 20);
        }
        function handleFormSubmit(evt) {
            if (evt.defaultPrevented)
                return;
            let actionRef = evt.submitter && evt.submitter.hasAttribute("formaction")
                ? evt.submitter.getAttribute("formaction")
                : evt.target.getAttribute("action");
            if (!actionRef)
                return;
            if (!actionRef.startsWith("https://action/")) {
                // normalize server actions
                const url = new URL(actionRef, mockBase);
                actionRef = router.parsePath(url.pathname + url.search);
                if (!actionRef.startsWith(actionBase))
                    return;
            }
            if (evt.target.method.toUpperCase() !== "POST")
                throw new Error("Only POST forms are supported for Actions");
            const handler = actions.get(actionRef);
            if (handler) {
                evt.preventDefault();
                const data = new FormData(evt.target, evt.submitter);
                handler.call({ r: router, f: evt.target }, evt.target.enctype === "multipart/form-data"
                    ? data
                    : new URLSearchParams(data));
            }
        }
        // ensure delegated event run first
        delegateEvents(["click", "submit"]);
        document.addEventListener("click", handleAnchorClick);
        if (preload) {
            document.addEventListener("mousemove", handleAnchorMove, { passive: true });
            document.addEventListener("focusin", handleAnchorPreload, { passive: true });
            document.addEventListener("touchstart", handleAnchorPreload, { passive: true });
        }
        document.addEventListener("submit", handleFormSubmit);
        onCleanup(() => {
            document.removeEventListener("click", handleAnchorClick);
            if (preload) {
                document.removeEventListener("mousemove", handleAnchorMove);
                document.removeEventListener("focusin", handleAnchorPreload);
                document.removeEventListener("touchstart", handleAnchorPreload);
            }
            document.removeEventListener("submit", handleFormSubmit);
        });
    };
}

function Router(props) {
    const getSource = () => {
        const url = window.location.pathname.replace(/^\/+/, "/") + window.location.search;
        const state = window.history.state && window.history.state._depth && Object.keys(window.history.state).length === 1 ? undefined : window.history.state;
        return {
            value: url + window.location.hash,
            state
        };
    };
    const beforeLeave = createBeforeLeave();
    return createRouter({
        get: getSource,
        set({ value, replace, scroll, state }) {
            if (replace) {
                window.history.replaceState(keepDepth(state), "", value);
            }
            else {
                window.history.pushState(state, "", value);
            }
            scrollToHash(decodeURIComponent(window.location.hash.slice(1)), scroll);
            saveCurrentDepth();
        },
        init: notify => bindEvent(window, "popstate", notifyIfNotBlocked(notify, delta => {
            if (delta) {
                return !beforeLeave.confirm(delta);
            }
            else {
                const s = getSource();
                return !beforeLeave.confirm(s.value, { state: s.state });
            }
        })),
        create: setupNativeEvents(props.preload, props.explicitLinks, props.actionBase, props.transformUrl),
        utils: {
            go: delta => window.history.go(delta),
            beforeLeave
        }
    })(props);
}

const $RAW = Symbol("store-raw"),
  $NODE = Symbol("store-node"),
  $HAS = Symbol("store-has"),
  $SELF = Symbol("store-self");
function wrap$1(value) {
  let p = value[$PROXY];
  if (!p) {
    Object.defineProperty(value, $PROXY, {
      value: p = new Proxy(value, proxyTraps$1)
    });
    if (!Array.isArray(value)) {
      const keys = Object.keys(value),
        desc = Object.getOwnPropertyDescriptors(value);
      for (let i = 0, l = keys.length; i < l; i++) {
        const prop = keys[i];
        if (desc[prop].get) {
          Object.defineProperty(value, prop, {
            enumerable: desc[prop].enumerable,
            get: desc[prop].get.bind(p)
          });
        }
      }
    }
  }
  return p;
}
function isWrappable(obj) {
  let proto;
  return obj != null && typeof obj === "object" && (obj[$PROXY] || !(proto = Object.getPrototypeOf(obj)) || proto === Object.prototype || Array.isArray(obj));
}
function unwrap(item, set = new Set()) {
  let result, unwrapped, v, prop;
  if (result = item != null && item[$RAW]) return result;
  if (!isWrappable(item) || set.has(item)) return item;
  if (Array.isArray(item)) {
    if (Object.isFrozen(item)) item = item.slice(0);else set.add(item);
    for (let i = 0, l = item.length; i < l; i++) {
      v = item[i];
      if ((unwrapped = unwrap(v, set)) !== v) item[i] = unwrapped;
    }
  } else {
    if (Object.isFrozen(item)) item = Object.assign({}, item);else set.add(item);
    const keys = Object.keys(item),
      desc = Object.getOwnPropertyDescriptors(item);
    for (let i = 0, l = keys.length; i < l; i++) {
      prop = keys[i];
      if (desc[prop].get) continue;
      v = item[prop];
      if ((unwrapped = unwrap(v, set)) !== v) item[prop] = unwrapped;
    }
  }
  return item;
}
function getNodes(target, symbol) {
  let nodes = target[symbol];
  if (!nodes) Object.defineProperty(target, symbol, {
    value: nodes = Object.create(null)
  });
  return nodes;
}
function getNode(nodes, property, value) {
  if (nodes[property]) return nodes[property];
  const [s, set] = createSignal(value, {
    equals: false,
    internal: true
  });
  s.$ = set;
  return nodes[property] = s;
}
function proxyDescriptor$1(target, property) {
  const desc = Reflect.getOwnPropertyDescriptor(target, property);
  if (!desc || desc.get || !desc.configurable || property === $PROXY || property === $NODE) return desc;
  delete desc.value;
  delete desc.writable;
  desc.get = () => target[$PROXY][property];
  return desc;
}
function trackSelf(target) {
  getListener() && getNode(getNodes(target, $NODE), $SELF)();
}
function ownKeys(target) {
  trackSelf(target);
  return Reflect.ownKeys(target);
}
const proxyTraps$1 = {
  get(target, property, receiver) {
    if (property === $RAW) return target;
    if (property === $PROXY) return receiver;
    if (property === $TRACK) {
      trackSelf(target);
      return receiver;
    }
    const nodes = getNodes(target, $NODE);
    const tracked = nodes[property];
    let value = tracked ? tracked() : target[property];
    if (property === $NODE || property === $HAS || property === "__proto__") return value;
    if (!tracked) {
      const desc = Object.getOwnPropertyDescriptor(target, property);
      if (getListener() && (typeof value !== "function" || target.hasOwnProperty(property)) && !(desc && desc.get)) value = getNode(nodes, property, value)();
    }
    return isWrappable(value) ? wrap$1(value) : value;
  },
  has(target, property) {
    if (property === $RAW || property === $PROXY || property === $TRACK || property === $NODE || property === $HAS || property === "__proto__") return true;
    getListener() && getNode(getNodes(target, $HAS), property)();
    return property in target;
  },
  set() {
    return true;
  },
  deleteProperty() {
    return true;
  },
  ownKeys: ownKeys,
  getOwnPropertyDescriptor: proxyDescriptor$1
};
function setProperty(state, property, value, deleting = false) {
  if (!deleting && state[property] === value) return;
  const prev = state[property],
    len = state.length;
  if (value === undefined) {
    delete state[property];
    if (state[$HAS] && state[$HAS][property] && prev !== undefined) state[$HAS][property].$();
  } else {
    state[property] = value;
    if (state[$HAS] && state[$HAS][property] && prev === undefined) state[$HAS][property].$();
  }
  let nodes = getNodes(state, $NODE),
    node;
  if (node = getNode(nodes, property, prev)) node.$(() => value);
  if (Array.isArray(state) && state.length !== len) {
    for (let i = state.length; i < len; i++) (node = nodes[i]) && node.$();
    (node = getNode(nodes, "length", len)) && node.$(state.length);
  }
  (node = nodes[$SELF]) && node.$();
}
function mergeStoreNode(state, value) {
  const keys = Object.keys(value);
  for (let i = 0; i < keys.length; i += 1) {
    const key = keys[i];
    setProperty(state, key, value[key]);
  }
}
function updateArray(current, next) {
  if (typeof next === "function") next = next(current);
  next = unwrap(next);
  if (Array.isArray(next)) {
    if (current === next) return;
    let i = 0,
      len = next.length;
    for (; i < len; i++) {
      const value = next[i];
      if (current[i] !== value) setProperty(current, i, value);
    }
    setProperty(current, "length", len);
  } else mergeStoreNode(current, next);
}
function updatePath(current, path, traversed = []) {
  let part,
    prev = current;
  if (path.length > 1) {
    part = path.shift();
    const partType = typeof part,
      isArray = Array.isArray(current);
    if (Array.isArray(part)) {
      for (let i = 0; i < part.length; i++) {
        updatePath(current, [part[i]].concat(path), traversed);
      }
      return;
    } else if (isArray && partType === "function") {
      for (let i = 0; i < current.length; i++) {
        if (part(current[i], i)) updatePath(current, [i].concat(path), traversed);
      }
      return;
    } else if (isArray && partType === "object") {
      const {
        from = 0,
        to = current.length - 1,
        by = 1
      } = part;
      for (let i = from; i <= to; i += by) {
        updatePath(current, [i].concat(path), traversed);
      }
      return;
    } else if (path.length > 1) {
      updatePath(current[part], path, [part].concat(traversed));
      return;
    }
    prev = current[part];
    traversed = [part].concat(traversed);
  }
  let value = path[0];
  if (typeof value === "function") {
    value = value(prev, traversed);
    if (value === prev) return;
  }
  if (part === undefined && value == undefined) return;
  value = unwrap(value);
  if (part === undefined || isWrappable(prev) && isWrappable(value) && !Array.isArray(value)) {
    mergeStoreNode(prev, value);
  } else setProperty(current, part, value);
}
function createStore(...[store, options]) {
  const unwrappedStore = unwrap(store || {});
  const isArray = Array.isArray(unwrappedStore);
  const wrappedStore = wrap$1(unwrappedStore);
  function setStore(...args) {
    batch(() => {
      isArray && args.length === 1 ? updateArray(unwrappedStore, args[0]) : updatePath(unwrappedStore, args);
    });
  }
  return [wrappedStore, setStore];
}
const producers = new WeakMap();
const setterTraps = {
  get(target, property) {
    if (property === $RAW) return target;
    const value = target[property];
    let proxy;
    return isWrappable(value) ? producers.get(value) || (producers.set(value, proxy = new Proxy(value, setterTraps)), proxy) : value;
  },
  set(target, property, value) {
    setProperty(target, property, unwrap(value));
    return true;
  },
  deleteProperty(target, property) {
    setProperty(target, property, undefined, true);
    return true;
  }
};
function produce(fn) {
  return state => {
    if (isWrappable(state)) {
      let proxy;
      if (!(proxy = producers.get(state))) {
        producers.set(state, proxy = new Proxy(state, setterTraps));
      }
      fn(proxy);
    }
    return state;
  };
}

function createTypeProps(def) {
  for (const key in def) {
    const descriptor = def[key];
    if (descriptor.type === "number") {
      descriptor.default = descriptor.default ?? 0;
    } else if (descriptor.type === "string") {
      descriptor.default = descriptor.default ?? "";
    } else if (descriptor.type === "color") {
      descriptor.default = descriptor.default ?? "#aaaaaa";
    } else {
      descriptor.default = descriptor.default ?? "";
    }
  }
  return def;
}
let nonce = 0;
function createSvgItemFromBlueprint(blueprint, id) {
  let props = {};
  for (const key in blueprint.props) {
    props[key] = blueprint.props[key].default;
  }
  if (id === void 0) {
    id = nonce++;
  }
  const item = {
    id,
    kind: blueprint.type,
    x: 0,
    y: 0,
    w: 256,
    h: 256,
    angle: 0,
    props,
    last_update: Date.now()
  };
  return item;
}
const SvgItemTablePropsDef = createTypeProps({
  "name": {
    type: "string",
    name: "prop_name"
  },
  "seat_radius": {
    type: "number",
    name: "prop_seat_radius",
    default: 21,
    min: 1
  },
  "seat_spacing": {
    type: "number",
    name: "prop_seat_spacing",
    default: 0,
    min: 0
  },
  "color": {
    type: "color",
    name: "prop_bg_color",
    default: "#aaaaaa"
  }
});
function isSvgItemTable(item) {
  return item.kind.startsWith("TABLE_");
}
const SvgItemTableTPropsDef = createTypeProps({
  ...SvgItemTablePropsDef,
  "top_height": {
    type: "number",
    name: "prop_top_height",
    default: 32,
    min: 32
  },
  "middle_width": {
    type: "number",
    name: "prop_middle_width",
    default: 32,
    min: 32
  }
});
function isSvgItemTableT(item) {
  return item.kind === "TABLE_T";
}
const SvgItemTableUPropsDef = createTypeProps({
  ...SvgItemTablePropsDef,
  "arms_width": {
    type: "number",
    name: "prop_arms_width",
    default: 32,
    min: 32
  },
  "bottom_height": {
    type: "number",
    name: "prop_bottom_height",
    default: 32,
    min: 32
  }
});
function isSvgItemTableU(item) {
  return item.kind === "TABLE_U";
}
createTypeProps({
  ...SvgItemTablePropsDef,
  "radius": {
    type: "number",
    name: "prop_radius",
    default: 64,
    min: 64
  }
});
const SvgItemIconPropsDef = createTypeProps({
  "icon": {
    type: "icon",
    name: "icon",
    default: "air-conditioner"
  },
  "label": {
    type: "string",
    name: "label"
  }
});
function isSvgItemIcon(item) {
  return item.kind === "ICON";
}
const SvgItems = {
  TABLE_RECT: {
    type: "TABLE_RECT",
    props: SvgItemTablePropsDef
  },
  TABLE_T: {
    type: "TABLE_T",
    props: SvgItemTableTPropsDef
  },
  TABLE_U: {
    type: "TABLE_U",
    props: SvgItemTableUPropsDef
  },
  TABLE_CIRCLE: {
    type: "TABLE_CIRCLE",
    props: SvgItemTablePropsDef
  },
  ICON: {
    type: "ICON",
    props: SvgItemIconPropsDef
  }
};

function SvgItemTableRectGenerator(item) {
  const points = [];
  const { w: width, h: height } = item;
  points.push({ x: 0, y: 0 });
  points.push({ x: width, y: 0 });
  points.push({ x: width, y: height });
  points.push({ x: 0, y: height });
  return [points, {}];
}
function SvgItemTableTGenerator(item) {
  const points = [];
  const { w: width, h: height, props } = item;
  const top_height = props.top_height;
  const side_width = props.middle_width;
  points.push({ x: 0, y: 0 });
  points.push({ x: width, y: 0 });
  points.push({ x: width, y: top_height });
  points.push({ x: width / 2 + side_width / 2, y: top_height });
  points.push({ x: width / 2 + side_width / 2, y: height });
  points.push({ x: width / 2 - side_width / 2, y: height });
  points.push({ x: width / 2 - side_width / 2, y: top_height });
  points.push({ x: 0, y: top_height });
  const params = {
    2: {
      seat_end_padding: props.seat_radius * 2 + 6
    },
    3: {
      seat_start_padding: 4
    },
    5: {
      seat_end_padding: 4
    },
    6: {
      seat_start_padding: props.seat_radius * 2 + 6
    }
  };
  return [points, params];
}
function SvgItemTableUGenerator(item) {
  const points = [];
  const { w: width, h: height, props } = item;
  const arm_width = item.props.arms_width;
  const bottom_height = item.props.bottom_height;
  points.push({ x: 0, y: 0 });
  points.push({ x: arm_width, y: 0 });
  points.push({ x: arm_width, y: height - bottom_height });
  points.push({ x: width - arm_width, y: height - bottom_height });
  points.push({ x: width - arm_width, y: 0 });
  points.push({ x: width, y: 0 });
  points.push({ x: width, y: height });
  points.push({ x: 0, y: height });
  const params = {
    1: {
      seat_end_padding: props.seat_radius * 2 + 6
    },
    2: {
      seat_start_padding: 4,
      seat_end_padding: 4
    },
    3: {
      seat_start_padding: props.seat_radius * 2 + 6
    }
  };
  return [points, params];
}

var _tmpl$$b = /* @__PURE__ */ template(`<svg><g><circle fill=white stroke=black stroke-dasharray="4 2"></circle><text font-size=12 text-anchor=middle fill=black></svg>`, false, true, false);
function SvgItemTableSeat(props) {
  return (() => {
    var _el$ = _tmpl$$b(), _el$2 = _el$.firstChild, _el$3 = _el$2.nextSibling;
    insert(_el$3, () => props.text ?? "");
    createRenderEffect((_p$) => {
      var _v$ = `
                translate(${props.x} ${props.y})
                rotate(${-props.angle})
                translate(${-props.x} ${-props.y})
            `, _v$2 = props.x, _v$3 = props.y, _v$4 = props.radius, _v$5 = props.x, _v$6 = props.y + 4;
      _v$ !== _p$.e && setAttribute(_el$, "transform", _p$.e = _v$);
      _v$2 !== _p$.t && setAttribute(_el$2, "cx", _p$.t = _v$2);
      _v$3 !== _p$.a && setAttribute(_el$2, "cy", _p$.a = _v$3);
      _v$4 !== _p$.o && setAttribute(_el$2, "r", _p$.o = _v$4);
      _v$5 !== _p$.i && setAttribute(_el$3, "x", _p$.i = _v$5);
      _v$6 !== _p$.n && setAttribute(_el$3, "y", _p$.n = _v$6);
      return _p$;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0,
      i: void 0,
      n: void 0
    });
    return _el$;
  })();
}

var _tmpl$$a = /* @__PURE__ */ template(`<svg><polygon stroke=black></svg>`, false, true, false), _tmpl$2$4 = /* @__PURE__ */ template(`<svg><text text-anchor=middle></svg>`, false, true, false);
function SvgItemTable(props) {
  const {
    item
  } = props;
  const [state, setState] = createStore({
    seats: [],
    points: [],
    sides: {}
  });
  const titleY = createMemo(() => {
    if (isSvgItemTableT(item)) {
      return item.props.top_height / 2 + 6;
    } else if (isSvgItemTableU(item)) {
      return item.h - item.props.bottom_height / 2 + 6;
    } else {
      return item.h / 2 + 6;
    }
  });
  createMemo(() => {
    return calculateTotalLength(state.points, state.sides);
  });
  calculatePoints();
  createEffect(() => {
    calculatePoints();
  });
  function calculateTotalLength(points, sides) {
    let total = 0;
    for (let i = 0; i < points.length; ++i) {
      const p0 = points[i];
      const p1 = points[(i + 1) % points.length];
      const params = {
        seat_start_padding: 0,
        seat_end_padding: 0,
        ...sides[i] || {}
      };
      let dx = p1.x - p0.x;
      let dy = p1.y - p0.y;
      let length = Math.sqrt(dx * dx + dy * dy);
      length -= params.seat_end_padding + params.seat_start_padding;
      total += length;
    }
    return total;
  }
  function calculatePoints() {
    let result;
    if (isSvgItemTableT(props.item)) {
      result = SvgItemTableTGenerator(props.item);
    } else if (isSvgItemTableU(props.item)) {
      result = SvgItemTableUGenerator(props.item);
    } else {
      result = SvgItemTableRectGenerator(props.item);
    }
    if (!result) {
      throw new Error("Can't find table generator!");
    }
    const [points, sides] = result;
    if (!points) {
      throw new Error("No generator for table!");
    }
    const seats = [];
    for (let i = 0; i < points.length; ++i) {
      const p0 = points[i];
      const p1 = points[(i + 1) % points.length];
      const params = {
        seat_start_padding: 0,
        seat_end_padding: 0,
        ...sides[i] || {}
      };
      let dx = p1.x - p0.x;
      let dy = p1.y - p0.y;
      let length = Math.sqrt(dx * dx + dy * dy);
      const nx = dx / length;
      const ny = dy / length;
      length -= params.seat_end_padding + params.seat_start_padding;
      dx = nx * length;
      dy = ny * length;
      const count = item.props.seat_radius > 0 ? Math.floor(length / (item.props.seat_radius * 2 + item.props.seat_spacing)) : 0;
      if (count === 0) {
        continue;
      }
      const stepX = dx / count;
      const stepY = dy / count;
      const perpX = dy / length;
      const perpY = -dx / length;
      for (let j = 0; j < count; j++) {
        const seatX = p0.x + params.seat_start_padding * nx + perpX * (item.props.seat_radius + 4) + stepX * (j + 0.5);
        const seatY = p0.y + params.seat_start_padding * ny + perpY * (item.props.seat_radius + 4) + stepY * (j + 0.5);
        seats.push({
          x: seatX,
          y: seatY
        });
      }
    }
    setState(produce((state2) => {
      state2.seats = seats;
      state2.sides = sides;
      state2.points = points;
    }));
  }
  return [(() => {
    var _el$ = _tmpl$$a();
    createRenderEffect((_p$) => {
      var _v$ = item.props?.color || "#aaaaaa", _v$2 = state.points.map((p) => `${p.x},${p.y}`).join(" ");
      _v$ !== _p$.e && setAttribute(_el$, "fill", _p$.e = _v$);
      _v$2 !== _p$.t && setAttribute(_el$, "points", _p$.t = _v$2);
      return _p$;
    }, {
      e: void 0,
      t: void 0
    });
    return _el$;
  })(), (() => {
    var _el$2 = _tmpl$2$4();
    insert(_el$2, () => item.props.name);
    createRenderEffect((_p$) => {
      var _v$3 = item.w / 2, _v$4 = titleY();
      _v$3 !== _p$.e && setAttribute(_el$2, "x", _p$.e = _v$3);
      _v$4 !== _p$.t && setAttribute(_el$2, "y", _p$.t = _v$4);
      return _p$;
    }, {
      e: void 0,
      t: void 0
    });
    return _el$2;
  })(), createComponent(For, {
    get each() {
      return state.seats;
    },
    children: (seat, seatIndex) => createComponent(SvgItemTableSeat, {
      get x() {
        return seat.x;
      },
      get y() {
        return seat.y;
      },
      get radius() {
        return item.props.seat_radius;
      },
      get angle() {
        return item.angle;
      },
      get text() {
        return (seatIndex() + 1).toFixed(0);
      }
    })
  })];
}

const SvgDrawerContext = createContext();
function SvgDrawerContextProvider(props) {
  const value = makeSvgDrawerContext();
  return createComponent(SvgDrawerContext.Provider, {
    value,
    get children() {
      return props.children;
    }
  });
}
function mergePatches(self, other) {
  if (self.type != "mod" || other.type != "mod") {
    return null;
  }
  if (self.id != other.id) {
    return null;
  }
  const finalValue = self.value;
  const walk = (self2, other2) => {
    for (const key in other2) {
      if (typeof other2[key] === "object") {
        if (!self2[key]) {
          self2[key] = other2[key];
        } else {
          walk(self2[key], other2[key]);
        }
      } else {
        self2[key] = other2[key];
      }
    }
  };
  walk(finalValue, other.value);
  return {
    type: "mod",
    id: self.id,
    value: finalValue
  };
}
function getItemDiff(self, other) {
  const diff = {};
  const keys = /* @__PURE__ */ new Set([...Object.keys(self), ...Object.keys(other)]);
  let changed = false;
  for (const key of keys) {
    if (!(key in self)) {
      diff[key] = other[key];
      changed = true;
      continue;
    }
    if (!(key in other)) {
      diff[key] = void 0;
      changed = true;
      continue;
    }
    if (typeof self[key] === "object" && typeof other[key] === "object") {
      const child = getItemDiff(self[key], other[key]);
      if (child) {
        diff[key] = child;
        changed = true;
      }
      continue;
    }
    if (self[key] != other[key]) {
      diff[key] = other[key];
      changed = true;
    }
  }
  return changed ? diff : null;
}
const makeSvgDrawerContext = () => {
  const [items, setItems] = createStore({});
  const [focusedItemIndex, setFocusedItemIndex] = createSignal(-1);
  const [zoom, setZoom] = createSignal(1);
  const [panX, setPanX] = createSignal(0);
  const [panY, setPanY] = createSignal(0);
  const [rootDOM, setRootDOM] = createSignal(null);
  const [patches, setPatches] = createStore([]);
  const removed_ids = /* @__PURE__ */ new Map();
  function addItem(id, item, emitPatch = true) {
    const patch = {
      type: "add",
      id,
      item
    };
    applyPatch(patch);
    if (emitPatch) setPatches(patches.length, patch);
  }
  function modifyItem(id, change, emitPatch = true) {
    const patch = {
      type: "mod",
      id,
      value: change
    };
    if (!change.last_update) {
      change.last_update = Date.now();
    }
    applyPatch(patch);
    if (emitPatch) setPatches(patches.length, patch);
  }
  function changeItemId(oldId, newId) {
    let refocus = false;
    if (focusedItemIndex() === oldId) {
      setFocusedItemIndex(-1);
      refocus = true;
    }
    setItems(oldId, "id", newId);
    setItems(newId, items[oldId]);
    setItems(oldId, void 0);
    refocus && setFocusedItemIndex(newId);
  }
  function removeItem(id, emitPatch = true) {
    const patch = {
      type: "del",
      id
    };
    applyPatch(patch);
    if (emitPatch) setPatches(patches.length, patch);
  }
  function applyPatch(patch) {
    if (patch.type === "add") {
      setItems(patch.id, patch.item);
    } else if (patch.type === "del") {
      removed_ids.set(patch.id, true);
      if (focusedItemIndex() === patch.id) {
        setFocusedItemIndex(-1);
      }
      setItems(patch.id, void 0);
    } else {
      setItems(patch.id, produce((item) => {
        const walk = (item2, change) => {
          for (const key in change) {
            if (typeof change[key] === "object") {
              if (!item2[key]) {
                item2[key] = change[key];
              } else {
                walk(item2[key], change[key]);
              }
            } else {
              item2[key] = change[key];
            }
          }
        };
        walk(item, patch.value);
        return item;
      }));
    }
  }
  return {
    items,
    removed_ids,
    //setItems,
    focusedItemIndex,
    setFocusedItemIndex,
    zoom,
    setZoom,
    panX,
    setPanX,
    panY,
    setPanY,
    rootDOM,
    setRootDOM,
    patches,
    addItem,
    changeItemId,
    modifyItem,
    removeItem
  };
};
function useSvgDrawerContext() {
  const context = useContext(SvgDrawerContext);
  if (!context) {
    throw new Error("useSvgDrawerContext must be used within a SvgDrawerContextProvider");
  }
  return context;
}

const scriptRel = /* @__PURE__ */ (function detectScriptRel() {
  const relList = typeof document !== "undefined" && document.createElement("link").relList;
  return relList && relList.supports && relList.supports("modulepreload") ? "modulepreload" : "preload";
})();const assetsURL = function(dep) { return "/svg-editor/"+dep };const seen = {};const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (true               && deps && deps.length > 0) {
    let allSettled2 = function(promises) {
      return Promise.all(
        promises.map(
          (p) => Promise.resolve(p).then(
            (value) => ({ status: "fulfilled", value }),
            (reason) => ({ status: "rejected", reason })
          )
        )
      );
    };
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = allSettled2(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};

var _tmpl$$9 = /* @__PURE__ */ template(`<svg><g><rect fill=none pointer-events=all></rect><text text-anchor=middle></svg>`, false, true, false);
const icons = /* #__PURE__ */ Object.assign({"/src/assets/air-conditioner.svg": () => __vitePreload(() => import('./d1af25db5d7632a2478f2.js'),true              ?[]:void 0),"/src/assets/arrow.svg": () => __vitePreload(() => import('./610efd84e427ed852d35d.js'),true              ?[]:void 0),"/src/assets/cake.svg": () => __vitePreload(() => import('./8370afb5545d35ea831c2.js'),true              ?[]:void 0),"/src/assets/caution-sign.svg": () => __vitePreload(() => import('./53998a4f41813ef5177eb.js'),true              ?[]:void 0),"/src/assets/compass.svg": () => __vitePreload(() => import('./ba4376de9396e001c1069.js'),true              ?[]:void 0),"/src/assets/dance-area.svg": () => __vitePreload(() => import('./d90faffc275e052b43795.js'),true              ?[]:void 0),"/src/assets/disability-sing.svg": () => __vitePreload(() => import('./759dbeec6d36e599c322e.js'),true              ?[]:void 0),"/src/assets/dj-controller.svg": () => __vitePreload(() => import('./62b3be44ec6e185a6302c.js'),true              ?[]:void 0),"/src/assets/electrical-outlet.svg": () => __vitePreload(() => import('./b7671c8c572261c3bbbbc.js'),true              ?[]:void 0),"/src/assets/fan.svg": () => __vitePreload(() => import('./abcfbb875d174003d9802.js'),true              ?[]:void 0),"/src/assets/firework.svg": () => __vitePreload(() => import('./efc7d041a7c22a1a165f6.js'),true              ?[]:void 0),"/src/assets/gifts.svg": () => __vitePreload(() => import('./4377f9fc99c9852d66897.js'),true              ?[]:void 0),"/src/assets/heater.svg": () => __vitePreload(() => import('./5cbd18c3a973d15e00d1b.js'),true              ?[]:void 0),"/src/assets/high-chair-sign.svg": () => __vitePreload(() => import('./f7a00faf220e0886e6bf7.js'),true              ?[]:void 0),"/src/assets/label.svg": () => __vitePreload(() => import('./9a19c80042deefe070347.js'),true              ?[]:void 0),"/src/assets/left door.svg": () => __vitePreload(() => import('./68c444a96c8a394cbc868.js'),true              ?[]:void 0),"/src/assets/light.svg": () => __vitePreload(() => import('./a8d0605c800a469f923d4.js'),true              ?[]:void 0),"/src/assets/long-table.svg": () => __vitePreload(() => import('./a3fa9dc2cee0b9b0d72c6.js'),true              ?[]:void 0),"/src/assets/microphone.svg": () => __vitePreload(() => import('./3c1c95574bf5663840e24.js'),true              ?[]:void 0),"/src/assets/pillar.svg": () => __vitePreload(() => import('./25ab6871a1f9fef902c5b.js'),true              ?[]:void 0),"/src/assets/right-door.svg": () => __vitePreload(() => import('./eea2f7f9953a1921498d2.js'),true              ?[]:void 0),"/src/assets/round-table.svg": () => __vitePreload(() => import('./ebe23943402a571723575.js'),true              ?[]:void 0),"/src/assets/row-of-chairs.svg": () => __vitePreload(() => import('./465798c973c49ee2b1107.js'),true              ?[]:void 0),"/src/assets/smoke.svg": () => __vitePreload(() => import('./8ce5f84c6acc15295ff3e.js'),true              ?[]:void 0),"/src/assets/sound.svg": () => __vitePreload(() => import('./5a76d063de67b39dfb96c.js'),true              ?[]:void 0),"/src/assets/square-table.svg": () => __vitePreload(() => import('./ac9382856b387217016a0.js'),true              ?[]:void 0),"/src/assets/stage.svg": () => __vitePreload(() => import('./b947453fe81322f365b30.js'),true              ?[]:void 0),"/src/assets/strainght-wall.svg": () => __vitePreload(() => import('./48ebea544b8d1e35b349a.js'),true              ?[]:void 0),"/src/assets/t-table.svg": () => __vitePreload(() => import('./12bc55761f0b11b8eb091.js'),true              ?[]:void 0),"/src/assets/target.svg": () => __vitePreload(() => import('./0f74e67ea9d8bb6934bcf.js'),true              ?[]:void 0),"/src/assets/tent.svg": () => __vitePreload(() => import('./87fc77a05f902d9258358.js'),true              ?[]:void 0),"/src/assets/toilet-sign.svg": () => __vitePreload(() => import('./b09190ad6c75a10628c5a.js'),true              ?[]:void 0),"/src/assets/tree.svg": () => __vitePreload(() => import('./b373769d086b9407b9875.js'),true              ?[]:void 0),"/src/assets/u-table.svg": () => __vitePreload(() => import('./4c7759021b3441aa61714.js'),true              ?[]:void 0),"/src/assets/water.svg": () => __vitePreload(() => import('./0a28c7b097ea2b13fe89b.js'),true              ?[]:void 0)

});
function SvgIcon(props) {
  const [component, setComponent] = createSignal();
  const fullpath = createMemo(() => "/src/assets/" + props.icon + ".svg");
  createEffect(() => {
    updateIconComponent();
  });
  async function updateIconComponent() {
    const importFn = icons[fullpath()];
    if (!importFn) {
      return;
    }
    const data = await importFn();
    setComponent(() => data.default);
  }
  return createComponent(Dynamic, {
    get component() {
      return component();
    },
    "pointer-event": "none",
    get width() {
      return props.width;
    },
    get height() {
      return props.height;
    }
  });
}
function SvgItemIcon(props) {
  return (() => {
    var _el$ = _tmpl$$9(), _el$2 = _el$.firstChild, _el$3 = _el$2.nextSibling;
    insert(_el$, createComponent(SvgIcon, {
      get icon() {
        return props.item.props.icon;
      },
      get width() {
        return props.item.w;
      },
      get height() {
        return props.item.h;
      }
    }), _el$3);
    insert(_el$3, () => props.item.props.label);
    createRenderEffect((_p$) => {
      var _v$ = props.item.w, _v$2 = props.item.h, _v$3 = props.item.w / 2, _v$4 = props.item.h + 20;
      _v$ !== _p$.e && setAttribute(_el$2, "width", _p$.e = _v$);
      _v$2 !== _p$.t && setAttribute(_el$2, "height", _p$.t = _v$2);
      _v$3 !== _p$.a && setAttribute(_el$3, "x", _p$.a = _v$3);
      _v$4 !== _p$.o && setAttribute(_el$3, "y", _p$.o = _v$4);
      return _p$;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0
    });
    return _el$;
  })();
}

var _tmpl$$8 = /* @__PURE__ */ template(`<svg><circle stroke=black></svg>`, false, true, false), _tmpl$2$3 = /* @__PURE__ */ template(`<svg><text text-anchor=middle></svg>`, false, true, false);
function SvgItemTableCircle(props) {
  const {
    item
  } = props;
  const [state, setState] = createStore({
    seats: [],
    radius: createMemo(() => Math.min(item.w, item.h) / 2)
  });
  calculatePoints();
  createEffect(() => {
    calculatePoints();
  });
  function calculatePoints() {
    const seats = [];
    const r = state.radius() + item.props.seat_radius + 8;
    const l = r * 2 * Math.PI;
    const total = Math.floor(l / (item.props.seat_radius + item.props.seat_spacing) * 0.5);
    for (let i = 0; i < total; ++i) {
      const angle = i / total * 360 - 90;
      const rad = angle * Math.PI / 180;
      const x = Math.cos(rad) * r;
      const y = Math.sin(rad) * r;
      seats.push({
        x: item.w / 2 + x,
        y: item.h / 2 + y
      });
    }
    setState("seats", seats);
  }
  return [(() => {
    var _el$ = _tmpl$$8();
    createRenderEffect((_p$) => {
      var _v$ = item.props?.color || "#aaaaaa", _v$2 = item.w / 2, _v$3 = item.h / 2, _v$4 = state.radius();
      _v$ !== _p$.e && setAttribute(_el$, "fill", _p$.e = _v$);
      _v$2 !== _p$.t && setAttribute(_el$, "cx", _p$.t = _v$2);
      _v$3 !== _p$.a && setAttribute(_el$, "cy", _p$.a = _v$3);
      _v$4 !== _p$.o && setAttribute(_el$, "r", _p$.o = _v$4);
      return _p$;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0
    });
    return _el$;
  })(), (() => {
    var _el$2 = _tmpl$2$3();
    insert(_el$2, () => item.props.name);
    createRenderEffect((_p$) => {
      var _v$5 = item.w / 2, _v$6 = item.h / 2 + 6;
      _v$5 !== _p$.e && setAttribute(_el$2, "x", _p$.e = _v$5);
      _v$6 !== _p$.t && setAttribute(_el$2, "y", _p$.t = _v$6);
      return _p$;
    }, {
      e: void 0,
      t: void 0
    });
    return _el$2;
  })(), createComponent(For, {
    get each() {
      return state.seats;
    },
    children: (seat, seatIndex) => createComponent(SvgItemTableSeat, {
      get x() {
        return seat.x;
      },
      get y() {
        return seat.y;
      },
      get radius() {
        return item.props.seat_radius;
      },
      get angle() {
        return item.angle;
      },
      get text() {
        return (seatIndex() + 1).toFixed(0);
      }
    })
  })];
}

var _tmpl$$7 = /* @__PURE__ */ template(`<div>Unknown item kind`), _tmpl$2$2 = /* @__PURE__ */ template(`<svg><g tabIndex=0><g transform></svg>`, false, true, false);
function SvgItemFactory(props) {
  const context = useSvgDrawerContext();
  let [lastMouseX, setLastMouseX] = createSignal(0);
  let [lastMouseY, setLastMouseY] = createSignal(0);
  function onContainerPointerDown(e) {
    const target = e.target;
    e.stopPropagation();
    e.preventDefault();
    target.setPointerCapture(e.pointerId);
    setLastMouseX(e.clientX);
    setLastMouseY(e.clientY);
    context.setFocusedItemIndex(props.item.id);
  }
  function onContainerPointerMove(e) {
    const target = e.target;
    if (!target.hasPointerCapture(e.pointerId)) return;
    const deltaX = (e.clientX - lastMouseX()) / context.zoom();
    const deltaY = (e.clientY - lastMouseY()) / context.zoom();
    const isInContext = context.items[props.item.id];
    if (!isInContext) {
      console.warn(`Can't find object`);
      return;
    }
    context.modifyItem(props.item.id, {
      x: props.item.x + deltaX,
      y: props.item.y + deltaY
    });
    setLastMouseX(e.clientX);
    setLastMouseY(e.clientY);
  }
  function onContainerPointerUp(e) {
    const target = e.target;
    target.releasePointerCapture(e.pointerId);
  }
  function onFocus(e) {
    e.stopPropagation();
    context.setFocusedItemIndex(props.item.id);
  }
  return (() => {
    var _el$ = _tmpl$2$2(), _el$2 = _el$.firstChild;
    addEventListener(_el$, "pointerup", onContainerPointerUp);
    addEventListener(_el$, "pointermove", onContainerPointerMove);
    addEventListener(_el$, "pointerdown", onContainerPointerDown);
    addEventListener(_el$, "focusin", onFocus);
    insert(_el$2, createComponent(Switch, {
      get children() {
        return [createComponent(Match, {
          get when() {
            return props.item.kind === "TABLE_RECT" || props.item.kind === "TABLE_T" || props.item.kind === "TABLE_U";
          },
          get children() {
            return createComponent(SvgItemTable, {
              get item() {
                return props.item;
              }
            });
          }
        }), createComponent(Match, {
          get when() {
            return props.item.kind === "TABLE_CIRCLE";
          },
          get children() {
            return createComponent(SvgItemTableCircle, {
              get item() {
                return props.item;
              }
            });
          }
        }), createComponent(Match, {
          get when() {
            return props.item.kind === "ICON";
          },
          get children() {
            return createComponent(SvgItemIcon, {
              get item() {
                return props.item;
              }
            });
          }
        }), createComponent(Match, {
          when: true,
          get children() {
            return _tmpl$$7();
          }
        })];
      }
    }));
    createRenderEffect(() => setAttribute(_el$, "transform", `
                translate(${props.item.x - props.item.w / 2} ${props.item.y - props.item.h / 2}),
                rotate(${props.item.angle} ${props.item.w / 2} ${props.item.h / 2})
            `));
    return _el$;
  })();
}

/**
* @license lucide-solid v0.483.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": 2,
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
var defaultAttributes_default = defaultAttributes;

var _tmpl$$6 = /* @__PURE__ */ template(`<svg>`);
var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
var mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();
var Icon = (props) => {
  const [localProps, rest] = splitProps(props, ["color", "size", "strokeWidth", "children", "class", "name", "iconNode", "absoluteStrokeWidth"]);
  return (() => {
    var _el$ = _tmpl$$6();
    spread(_el$, mergeProps(defaultAttributes_default, {
      get width() {
        return localProps.size ?? defaultAttributes_default.width;
      },
      get height() {
        return localProps.size ?? defaultAttributes_default.height;
      },
      get stroke() {
        return localProps.color ?? defaultAttributes_default.stroke;
      },
      get ["stroke-width"]() {
        return memo(() => !!localProps.absoluteStrokeWidth)() ? Number(localProps.strokeWidth ?? defaultAttributes_default["stroke-width"]) * 24 / Number(localProps.size) : Number(localProps.strokeWidth ?? defaultAttributes_default["stroke-width"]);
      },
      get ["class"]() {
        return mergeClasses("lucide", "lucide-icon", localProps.name != null ? `lucide-${toKebabCase(localProps?.name)}` : void 0, localProps.class != null ? localProps.class : "");
      }
    }, rest), true, true);
    insert(_el$, createComponent(For, {
      get each() {
        return localProps.iconNode;
      },
      children: ([elementName, attrs]) => {
        return createComponent(Dynamic, mergeProps({
          component: elementName
        }, attrs));
      }
    }));
    return _el$;
  })();
};
var Icon_default = Icon;

var iconNode$3 = [["path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
  key: "ih7n3h"
}], ["polyline", {
  points: "7 10 12 15 17 10",
  key: "2ggqvy"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "15",
  y2: "3",
  key: "1vk2je"
}]];
var Download = (props) => createComponent(Icon_default, mergeProps(props, {
  name: "Download",
  iconNode: iconNode$3
}));
var download_default = Download;

var iconNode$2 = [["path", {
  d: "M15 3h6v6",
  key: "1q9fwt"
}], ["path", {
  d: "M10 14 21 3",
  key: "gplh6r"
}], ["path", {
  d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
  key: "a6xqqp"
}]];
var ExternalLink = (props) => createComponent(Icon_default, mergeProps(props, {
  name: "ExternalLink",
  iconNode: iconNode$2
}));
var external_link_default = ExternalLink;

var iconNode$1 = [["path", {
  d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8",
  key: "1p45f6"
}], ["path", {
  d: "M21 3v5h-5",
  key: "1q7to0"
}]];
var RotateCw = (props) => createComponent(Icon_default, mergeProps(props, {
  name: "RotateCw",
  iconNode: iconNode$1
}));
var rotate_cw_default = RotateCw;

var iconNode = [["path", {
  d: "M3 6h18",
  key: "d0wm0j"
}], ["path", {
  d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",
  key: "4alrt4"
}], ["path", {
  d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",
  key: "v07s0e"
}], ["line", {
  x1: "10",
  x2: "10",
  y1: "11",
  y2: "17",
  key: "1uufr5"
}], ["line", {
  x1: "14",
  x2: "14",
  y1: "11",
  y2: "17",
  key: "xtxkd"
}]];
var Trash2 = (props) => createComponent(Icon_default, mergeProps(props, {
  name: "Trash2",
  iconNode
}));
var trash_2_default = Trash2;

var _tmpl$$5 = /* @__PURE__ */ template(`<svg><g class=pointer-events-auto><rect fill=none stroke=#64748B stroke-width=2></rect><circle fill=white stroke=gray stroke-width=2 style=cursor:ne-resize></circle><circle fill=white stroke=gray stroke-width=2 style=cursor:nw-resize></circle><circle fill=white stroke=gray stroke-width=2 style=cursor:sw-resize></circle><circle fill=white stroke=gray stroke-width=2 style=cursor:se-resize></circle><line stroke=gray stroke-width=1></line><g><rect fill=transparent pointer-events=all style=cursor:grab></svg>`, false, true, false);
function SvgItemInspector(props) {
  const context = useSvgDrawerContext();
  const padding = createMemo(() => ({
    l: 0,
    r: 0,
    t: 0,
    b: 0
  }));
  const x = createMemo(() => -padding().l * 3);
  const y = createMemo(() => -padding().t * 3);
  const width = createMemo(() => props.item.w + padding().l * 3 + padding().r * 3);
  const height = createMemo(() => props.item.h + padding().t * 3 + padding().b * 3);
  let lastMouseX = 0, lastMouseY = 0;
  function onResizeHandlePointerDown(e) {
    const target = e.target;
    e.stopPropagation();
    e.preventDefault();
    target.setPointerCapture(e.pointerId);
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
  }
  function onResizeHandlePointerMove(e, type) {
    const target = e.target;
    if (!target.hasPointerCapture(e.pointerId)) return;
    e.stopPropagation();
    const deltaX = (e.clientX - lastMouseX) / context.zoom();
    const deltaY = -(e.clientY - lastMouseY) / context.zoom();
    if (deltaX == 0 && deltaY == 0) {
      return;
    }
    const rad = props.item.angle * Math.PI / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    const isInContext = context.items[props.item.id];
    if (!isInContext) {
      console.warn(`Can't find object`);
      return;
    }
    const rx = cos * deltaX - sin * deltaY;
    const ry = sin * deltaX + cos * deltaY;
    let deltaWidth = rx;
    let deltaHeight = ry;
    let finalWidth;
    let finalHeight;
    if (type == "RT" || type == "RB") {
      finalWidth = props.item.w + deltaWidth;
    } else {
      finalWidth = props.item.w - deltaWidth;
    }
    if (type == "RT" || type == "LT") {
      finalHeight = props.item.h + deltaHeight;
    } else {
      finalHeight = props.item.h - deltaHeight;
    }
    const minWidth = 64;
    const minHeight = 64;
    if (finalWidth >= minWidth && finalHeight >= minHeight) {
      context.modifyItem(props.item.id, {
        x: props.item.x + deltaX / 2,
        y: props.item.y - deltaY / 2,
        w: finalWidth,
        h: finalHeight
      });
    }
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
  }
  function onResizeHandlePointerUp(e) {
    const target = e.target;
    e.stopPropagation();
    target.releasePointerCapture(e.pointerId);
  }
  function onRotateHandlePointerDown(e) {
    const target = e.target;
    e.stopPropagation();
    e.preventDefault();
    target.setPointerCapture(e.pointerId);
    lastMouseX = e.clientX;
  }
  function onRotateHandlePointerMove(e) {
    const target = e.target;
    if (!target.hasPointerCapture(e.pointerId)) return;
    e.stopPropagation();
    const deltaX = e.clientX - lastMouseX;
    const newAngle = Math.floor(props.item.angle + deltaX * 0.25);
    if (newAngle === props.item.angle) {
      return;
    }
    const isInContext = context.items[props.item.id];
    if (!isInContext) {
      console.warn(`Can't find object`);
      return;
    }
    context.modifyItem(props.item.id, {
      angle: newAngle
    });
    lastMouseX = e.clientX;
    console.log("Rotate handle pointer move");
  }
  function onRotateHandlePointerUp(e) {
    const target = e.target;
    e.stopPropagation();
    target.releasePointerCapture(e.pointerId);
  }
  return (() => {
    var _el$ = _tmpl$$5(), _el$2 = _el$.firstChild, _el$3 = _el$2.nextSibling, _el$4 = _el$3.nextSibling, _el$5 = _el$4.nextSibling, _el$6 = _el$5.nextSibling, _el$7 = _el$6.nextSibling, _el$8 = _el$7.nextSibling, _el$9 = _el$8.firstChild;
    addEventListener(_el$3, "pointerup", onResizeHandlePointerUp);
    addEventListener(_el$3, "pointermove", (e) => onResizeHandlePointerMove(e, "RT"));
    addEventListener(_el$3, "pointerdown", onResizeHandlePointerDown);
    addEventListener(_el$4, "pointerup", onResizeHandlePointerUp);
    addEventListener(_el$4, "pointermove", (e) => onResizeHandlePointerMove(e, "LT"));
    addEventListener(_el$4, "pointerdown", onResizeHandlePointerDown);
    addEventListener(_el$5, "pointerup", onResizeHandlePointerUp);
    addEventListener(_el$5, "pointermove", (e) => onResizeHandlePointerMove(e, "LB"));
    addEventListener(_el$5, "pointerdown", onResizeHandlePointerDown);
    addEventListener(_el$6, "pointerup", onResizeHandlePointerUp);
    addEventListener(_el$6, "pointermove", (e) => onResizeHandlePointerMove(e, "RB"));
    addEventListener(_el$6, "pointerdown", onResizeHandlePointerDown);
    addEventListener(_el$8, "pointerup", onRotateHandlePointerUp);
    addEventListener(_el$8, "pointermove", onRotateHandlePointerMove);
    addEventListener(_el$8, "pointerdown", onRotateHandlePointerDown);
    insert(_el$8, createComponent(rotate_cw_default, {
      get x() {
        return x() + width() / 2 - 6 / context.zoom();
      },
      get y() {
        return y() - 24 - 6 / context.zoom();
      },
      get width() {
        return 12 / context.zoom();
      },
      get height() {
        return 12 / context.zoom();
      },
      stroke: "gray",
      "stroke-width": "2",
      "pointer-events": "none"
    }), null);
    createRenderEffect((_p$) => {
      var _v$ = `
                translate(${props.item.x - props.item.w / 2} ${props.item.y - props.item.h / 2}),
                rotate(${props.item.angle} ${props.item.w / 2} ${props.item.h / 2})
            `, _v$2 = x(), _v$3 = y(), _v$4 = width(), _v$5 = height(), _v$6 = x() + width(), _v$7 = y(), _v$8 = 4 / context.zoom(), _v$9 = x(), _v$0 = y(), _v$1 = 4 / context.zoom(), _v$10 = x(), _v$11 = y() + height(), _v$12 = 4 / context.zoom(), _v$13 = x() + width(), _v$14 = y() + height(), _v$15 = 4 / context.zoom(), _v$16 = x() + width() / 2, _v$17 = y(), _v$18 = x() + width() / 2, _v$19 = y() - 16, _v$20 = x() + width() / 2 - 16 / context.zoom(), _v$21 = y() - 24 - 16 / context.zoom(), _v$22 = 32 / context.zoom(), _v$23 = 32 / context.zoom();
      _v$ !== _p$.e && setAttribute(_el$, "transform", _p$.e = _v$);
      _v$2 !== _p$.t && setAttribute(_el$2, "x", _p$.t = _v$2);
      _v$3 !== _p$.a && setAttribute(_el$2, "y", _p$.a = _v$3);
      _v$4 !== _p$.o && setAttribute(_el$2, "width", _p$.o = _v$4);
      _v$5 !== _p$.i && setAttribute(_el$2, "height", _p$.i = _v$5);
      _v$6 !== _p$.n && setAttribute(_el$3, "cx", _p$.n = _v$6);
      _v$7 !== _p$.s && setAttribute(_el$3, "cy", _p$.s = _v$7);
      _v$8 !== _p$.h && setAttribute(_el$3, "r", _p$.h = _v$8);
      _v$9 !== _p$.r && setAttribute(_el$4, "cx", _p$.r = _v$9);
      _v$0 !== _p$.d && setAttribute(_el$4, "cy", _p$.d = _v$0);
      _v$1 !== _p$.l && setAttribute(_el$4, "r", _p$.l = _v$1);
      _v$10 !== _p$.u && setAttribute(_el$5, "cx", _p$.u = _v$10);
      _v$11 !== _p$.c && setAttribute(_el$5, "cy", _p$.c = _v$11);
      _v$12 !== _p$.w && setAttribute(_el$5, "r", _p$.w = _v$12);
      _v$13 !== _p$.m && setAttribute(_el$6, "cx", _p$.m = _v$13);
      _v$14 !== _p$.f && setAttribute(_el$6, "cy", _p$.f = _v$14);
      _v$15 !== _p$.y && setAttribute(_el$6, "r", _p$.y = _v$15);
      _v$16 !== _p$.g && setAttribute(_el$7, "x1", _p$.g = _v$16);
      _v$17 !== _p$.p && setAttribute(_el$7, "y1", _p$.p = _v$17);
      _v$18 !== _p$.b && setAttribute(_el$7, "x2", _p$.b = _v$18);
      _v$19 !== _p$.T && setAttribute(_el$7, "y2", _p$.T = _v$19);
      _v$20 !== _p$.A && setAttribute(_el$9, "x", _p$.A = _v$20);
      _v$21 !== _p$.O && setAttribute(_el$9, "y", _p$.O = _v$21);
      _v$22 !== _p$.I && setAttribute(_el$9, "width", _p$.I = _v$22);
      _v$23 !== _p$.S && setAttribute(_el$9, "height", _p$.S = _v$23);
      return _p$;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0,
      i: void 0,
      n: void 0,
      s: void 0,
      h: void 0,
      r: void 0,
      d: void 0,
      l: void 0,
      u: void 0,
      c: void 0,
      w: void 0,
      m: void 0,
      f: void 0,
      y: void 0,
      g: void 0,
      p: void 0,
      b: void 0,
      T: void 0,
      A: void 0,
      O: void 0,
      I: void 0,
      S: void 0
    });
    return _el$;
  })();
}

const isNonNullable = (i) => i != null;
const filterNonNullable = (arr) => arr.filter(isNonNullable);
/**
 * Accesses the value of a MaybeAccessor
 * @example
 * ```ts
 * access("foo") // => "foo"
 * access(() => "foo") // => "foo"
 * ```
 */
const access = (v) => typeof v === "function" && !v.length ? v() : v;
const asArray = (value) => Array.isArray(value) ? value : value ? [value] : [];
/**
 * Handle items removed and added to the array by diffing it by refference.
 *
 * @param current new array instance
 * @param prev previous array copy
 * @param handleAdded called once for every added item to array
 * @param handleRemoved called once for every removed from array
 */
function handleDiffArray(current, prev, handleAdded, handleRemoved) {
    const currLength = current.length;
    const prevLength = prev.length;
    let i = 0;
    if (!prevLength) {
        for (; i < currLength; i++)
            handleAdded(current[i]);
        return;
    }
    if (!currLength) {
        for (; i < prevLength; i++)
            handleRemoved(prev[i]);
        return;
    }
    for (; i < prevLength; i++) {
        if (prev[i] !== current[i])
            break;
    }
    let prevEl;
    let currEl;
    prev = prev.slice(i);
    current = current.slice(i);
    for (prevEl of prev) {
        if (!current.includes(prevEl))
            handleRemoved(prevEl);
    }
    for (currEl of current) {
        if (!prev.includes(currEl))
            handleAdded(currEl);
    }
}

/**
 * Instantiate a new ResizeObserver that automatically get's disposed on cleanup.
 *
 * @param callback handler called once element size changes
 * @param options ResizeObserver options
 * @returns `observe` and `unobserve` functions
 */
function makeResizeObserver(callback, options) {
    const observer = new ResizeObserver(callback);
    onCleanup(observer.disconnect.bind(observer));
    return {
        observe: ref => observer.observe(ref, options),
        unobserve: observer.unobserve.bind(observer),
    };
}
/**
 * Create resize observer instance, listening for changes to size of the reactive {@link targets} array.
 *
 * @param targets Elements to be observed. Can be a reactive signal or store top-level array.
 * @param onResize - Function handler to trigger on element resize
 *
 * @example
 * ```tsx
 * let ref
 * createResizeObserver(() => ref, ({ width, height }, el) => {
 *   if (el === ref) console.log(width, height)
 * });
 * <div ref={ref}/>
 * ```
 */
function createResizeObserver(targets, onResize, options) {
    const previousMap = new WeakMap(), { observe, unobserve } = makeResizeObserver(entries => {
        for (const entry of entries) {
            const { contentRect, target } = entry, width = Math.round(contentRect.width), height = Math.round(contentRect.height), previous = previousMap.get(target);
            if (!previous || previous.width !== width || previous.height !== height) {
                onResize(contentRect, target, entry);
                previousMap.set(target, { width, height });
            }
        }
    }, options);
    createEffect((prev) => {
        const refs = filterNonNullable(asArray(access(targets)));
        handleDiffArray(refs, prev, observe, unobserve);
        return refs;
    }, []);
}

var _tmpl$$4 = /* @__PURE__ */ template(`<div class="relative w-full h-full select-none cursor-move overflow-hidden"><svg width=100% height=100% style=background-color:white><g><line x1=0 y1=-10000 x2=0 y2=10000 stroke=lightgray></line><line x1=-10000 y1=0 x2=10000 y2=0 stroke=lightgray></line></g></svg><svg class="absolute top-0 left-0 pointer-events-none"width=100% height=100%><g>`);
function SvgDrawer() {
  const context = useSvgDrawerContext();
  let svgDOM = null;
  let [cellX, setCellX] = createSignal(32);
  let [cellY, setCellY] = createSignal(32);
  const [state, setState] = createStore({
    clientWidth: 0,
    clientHeight: 0
  });
  onMount(() => {
    context.setRootDOM(svgDOM);
    setState("clientWidth", svgDOM.clientWidth);
    setState("clientHeight", svgDOM.clientHeight);
    createResizeObserver(svgDOM, ({
      width,
      height
    }, el) => {
      if (el === svgDOM) {
        console.log(`SVG DOM resized to ${width}x${height}`);
        setState("clientWidth", width);
        setState("clientHeight", height);
      }
    });
    console.log("SvgDrawer mounted");
  });
  onCleanup(() => {
    if (context.rootDOM() === svgDOM) {
      context.setRootDOM(null);
    }
  });
  createEffect(() => {
    context.setZoom(Math.floor(cellX()) / 32);
  });
  createEffect(() => {
    console.log(`Zoom: ${context.zoom()}`);
  });
  let lastMouseX = 0;
  let lastMouseY = 0;
  function onPointerDown(e) {
    const target = e.currentTarget;
    e.preventDefault();
    target.setPointerCapture(e.pointerId);
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
    context.setFocusedItemIndex(-1);
  }
  function onPointerMove(e) {
    const target = e.currentTarget;
    if (!target.hasPointerCapture(e.pointerId)) return;
    e.stopPropagation();
    const deltaX = e.clientX - lastMouseX;
    const deltaY = e.clientY - lastMouseY;
    context.setPanX(context.panX() + deltaX);
    context.setPanY(context.panY() + deltaY);
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
  }
  function onPointerUp(e) {
    const target = e.currentTarget;
    e.stopPropagation();
    target.releasePointerCapture(e.pointerId);
  }
  function onWheel(e) {
    e.preventDefault();
    const oldZoom = context.zoom();
    setCellX(Math.max(8, Math.min(256, cellX() - e.deltaY * 0.1)));
    setCellY(Math.max(8, Math.min(256, cellY() - e.deltaY * 0.1)));
    const newZoom = context.zoom();
    const oldMouseX = (e.clientX - context.panX() - state.clientWidth / 2) / oldZoom;
    const oldMouseY = (e.clientY - context.panY() - state.clientHeight / 2) / oldZoom;
    const newMouseX = (e.clientX - context.panX() - state.clientWidth / 2) / newZoom;
    const newMouseY = (e.clientY - context.panY() - state.clientHeight / 2) / newZoom;
    context.setPanX(context.panX() + (newMouseX - oldMouseX) * newZoom);
    context.setPanY(context.panY() + (newMouseY - oldMouseY) * newZoom);
  }
  return (() => {
    var _el$ = _tmpl$$4(), _el$2 = _el$.firstChild, _el$3 = _el$2.firstChild, _el$4 = _el$3.firstChild, _el$5 = _el$4.nextSibling, _el$6 = _el$2.nextSibling, _el$7 = _el$6.firstChild;
    addEventListener(_el$2, "pointerup", onPointerUp);
    addEventListener(_el$2, "pointermove", onPointerMove);
    addEventListener(_el$2, "pointerdown", onPointerDown);
    addEventListener(_el$2, "wheel", onWheel);
    var _ref$ = svgDOM;
    typeof _ref$ === "function" ? use(_ref$, _el$2) : svgDOM = _el$2;
    insert(_el$3, createComponent(For, {
      get each() {
        return Object.keys(context.items);
      },
      children: (key) => {
        const item = context.items[key];
        if (!item) {
          return;
        }
        return createComponent(SvgItemFactory, {
          item
        });
      }
    }), null);
    insert(_el$7, createComponent(Show, {
      get when() {
        return context.focusedItemIndex() != -1;
      },
      get children() {
        return createComponent(SvgItemInspector, {
          get item() {
            return context.items[context.focusedItemIndex()];
          }
        });
      }
    }));
    createRenderEffect((_p$) => {
      var _v$ = `0 0 ${state.clientWidth} ${state.clientHeight}`, _v$2 = `radial-gradient(rgb(200 200 200 / 0.8) ${Math.max(1.2 * context.zoom(), 0.5)}px, transparent 0)`, _v$3 = `${Math.floor(cellX())}px ${Math.floor(cellY())}px`, _v$4 = `${(context.panX() + state.clientWidth / 2) % Math.floor(cellX())}px ${(context.panY() + state.clientHeight / 2) % Math.floor(cellY())}px`, _v$5 = `translate(${context.panX() + state.clientWidth / 2}, ${context.panY() + state.clientHeight / 2}) scale(${context.zoom()})`, _v$6 = Math.max(Math.min(1 * context.zoom(), 1), 0.2), _v$7 = Math.max(Math.min(1 * context.zoom(), 1), 0.2), _v$8 = `translate(${context.panX() + state.clientWidth / 2}, ${context.panY() + state.clientHeight / 2}) scale(${context.zoom()})`;
      _v$ !== _p$.e && setAttribute(_el$2, "viewBox", _p$.e = _v$);
      _v$2 !== _p$.t && setStyleProperty(_el$2, "background-image", _p$.t = _v$2);
      _v$3 !== _p$.a && setStyleProperty(_el$2, "background-size", _p$.a = _v$3);
      _v$4 !== _p$.o && setStyleProperty(_el$2, "background-position", _p$.o = _v$4);
      _v$5 !== _p$.i && setAttribute(_el$3, "transform", _p$.i = _v$5);
      _v$6 !== _p$.n && setAttribute(_el$4, "stroke-width", _p$.n = _v$6);
      _v$7 !== _p$.s && setAttribute(_el$5, "stroke-width", _p$.s = _v$7);
      _v$8 !== _p$.h && setAttribute(_el$7, "transform", _p$.h = _v$8);
      return _p$;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0,
      i: void 0,
      n: void 0,
      s: void 0,
      h: void 0
    });
    return _el$;
  })();
}

const SPRITES_META = {
  "air-conditioner": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "arrow": {
    viewBox: "135.394 151.529 242.004 207.123",
    width: 234.004,
    height: 199.123
  },
  "cake": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "caution-sign": {
    viewBox: "126.426 107 259.148 225.5",
    width: 251.148,
    height: 217.5
  },
  "compass": {
    viewBox: "148 56.454 224.5 313.546",
    width: 216.5,
    height: 305.546
  },
  "dance-area": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "disability-sing": {
    viewBox: "128 98 256.003 312",
    width: 248.003,
    height: 304
  },
  "dj-controller": {
    viewBox: "79.5 103.5 303 203",
    width: 295,
    height: 195
  },
  "electrical-outlet": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "fan": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "firework": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "gifts": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "heater": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "high-chair-sign": {
    viewBox: "173 43.5 219 361.5",
    width: 211,
    height: 353.5
  },
  "label": {
    viewBox: "146.138 121.49 238.965 226.182",
    width: 230.965,
    height: 218.182
  },
  "left door": {
    viewBox: "99.86 108.63 312.06 308",
    width: 304.06,
    height: 300
  },
  "light": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "long-table": {
    viewBox: "27.385 130 478.018 328",
    width: 470.018,
    height: 320
  },
  "microphone": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "pillar": {
    viewBox: "177 177 158 158",
    width: 150,
    height: 150
  },
  "right-door": {
    viewBox: "97.95 73.5 312.05 333.5",
    width: 304.05,
    height: 325.5
  },
  "round-table": {
    viewBox: "92 100 328 328",
    width: 320,
    height: 320
  },
  "row-of-chairs": {
    viewBox: "102 180 308 65.5",
    width: 300,
    height: 57.5
  },
  "smoke": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "sound": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "square-table": {
    viewBox: "84 80 332 328",
    width: 324,
    height: 320
  },
  "stage": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  },
  "strainght-wall": {
    viewBox: "102 252 308 8",
    width: 300,
    height: 0
  },
  "t-table": {
    viewBox: "0 0 512 512",
    width: 512,
    height: 512
  },
  "target": {
    viewBox: "126.867 143.739 223.05 220.812",
    width: 215.05,
    height: 212.812
  },
  "tent": {
    viewBox: "77 125 358.01 258.01",
    width: 350.01,
    height: 250.01
  },
  "toilet-sign": {
    viewBox: "98.397 102.226 315.014 301.474",
    width: 307.014,
    height: 293.474
  },
  "tree": {
    viewBox: "102 152 308 208",
    width: 300,
    height: 200
  },
  "u-table": {
    viewBox: "0 0 512 512",
    width: 512,
    height: 512
  },
  "water": {
    viewBox: "102 102 308 308",
    width: 300,
    height: 300
  }
};

const isDict = (value) => value != null &&
    ((value = Object.getPrototypeOf(value)), value === Array.prototype || value === Object.prototype);
function visitDict(flat_dict, dict, path) {
    for (const [key, value] of Object.entries(dict)) {
        const key_path = `${path}.${key}`;
        flat_dict[key_path] = value;
        isDict(value) && visitDict(flat_dict, value, key_path);
    }
}
/**
 * Flatten a nested dictionary into a flat dictionary.
 *
 * This way each nested property is available as a flat key.
 *
 * @example
 * ```ts
 * const dict = {
 *   a: {
 *     foo: "foo",
 *     b: { bar: 1 }
 *   }
 * }
 *
 * const flat_dict = flatten(dict);
 *
 * flat_dict === {
 *   a: {
 *     foo: "foo",
 *     b: { bar: 1 }
 *   },
 *   "a.foo": "foo",
 *   "a.b": { bar: 1 },
 *   "a.b.bar": 1,
 * }
 * ```
 */
function flatten(dict) {
    const flat_dict = { ...dict };
    for (const [key, value] of Object.entries(dict)) {
        isDict(value) && visitDict(flat_dict, value, key);
    }
    return flat_dict;
}
/**
 * Template resolver that does nothing. It's used as a fallback when no template resolver is provided.
 */
const identityResolveTemplate = (v => v);
function translator(dict, resolveTemplate = identityResolveTemplate) {
    return (path, ...args) => {
        if (path[0] === ".")
            path = path.slice(1);
        const value = dict()?.[path];
        switch (typeof value) {
            case "function":
                return value(...args);
            case "string":
                return resolveTemplate(value, args[0]);
            default:
                return value;
        }
    };
}

const dict$1 = {
  add_element: "Add Element",
  export: "Export",
  guests: "Guests",
  export_svg: "Export to SVG",
  export_png: "Export to PNG",
  category_tables: "Tables",
  category_icons: "Icons",
  rect_table: "Rect Table",
  t_table: "T Table",
  u_table: "U Table",
  round_table: "Round Table",
  icon: "Icon",
  label: "Label",
  category_transform: "Transform",
  category_parameters: "Parameters",
  prop_x: "X",
  prop_y: "Y",
  prop_width: "Width",
  prop_height: "Length",
  prop_radius: "Radius",
  prop_angle: "Angle",
  prop_name: "Name",
  prop_bg_color: "Background Color",
  prop_seats: "Seat Amount",
  prop_seat_radius: "Seat Radius",
  prop_seat_spacing: "Seat Spacing",
  prop_top_height: "Top Height",
  prop_middle_width: "Middle Width",
  prop_arms_width: "Arms Width",
  prop_bottom_height: "Bottom Height"
};

const dict = {
  add_element: "Dodaj Element",
  export: "Eksportuj",
  guests: "Goście",
  export_svg: "Eksportuj do SVG",
  export_png: "Eksportuj do PNG",
  category_tables: "Stoły",
  category_icons: "Ikony",
  rect_table: "Stół Kwadratowy",
  t_table: "Stół T",
  u_table: "Stół U",
  round_table: "Stół Okrągły",
  icon: "Ikona",
  label: "Napis",
  category_transform: "Pozycja",
  category_parameters: "Parametry",
  prop_x: "X",
  prop_y: "Y",
  prop_width: "Szerokość",
  prop_height: "Długość",
  prop_radius: "Promień",
  prop_angle: "Kąt",
  prop_name: "Nazwa",
  prop_bg_color: "Kolor Tła",
  prop_seats: "Ilość Krzeseł",
  prop_seat_radius: "Promień Krzesła",
  prop_seat_spacing: "Rozstaw Krzeseł",
  prop_top_height: "Wysokość Góry",
  prop_middle_width: "Szerokość Środka",
  prop_arms_width: "Szerokość Ramion",
  prop_bottom_height: "Wysokość Dołu"
};

const I18nContext = createContext();
function I18nContextProvider(props) {
  const value = makeI18nContext();
  return createComponent(I18nContext.Provider, {
    value,
    get children() {
      return props.children;
    }
  });
}
const makeI18nContext = () => {
  const dictionaries = {
    en: dict$1,
    pl: dict
  };
  const [locale, setLocale] = createSignal("pl");
  const dict$2 = createMemo(() => flatten(dictionaries[locale()]));
  const t = translator(dict$2);
  const t_dynamic = translator(dict$2);
  return {
    locale,
    setLocale,
    dict: dict$2,
    t,
    t_dynamic
  };
};
function useI18nContext() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error("useI18nContext must be used within a I18nContextProvider");
  }
  return context;
}

var _tmpl$$3 = /* @__PURE__ */ template(`<div class="absolute w-82 top-0 bottom-0 right-0 flex flex-col bg-white border border-gray-400"><div class="flex items-center p-2"><h1 class="grow p-2 font-bold text-xl">Obiekt ID #</h1><button class="rounded-md shadow-inner shadow-black/40 p-3 flex justify-center items-center cursor-pointer"></button></div><div class="grow flex flex-col gap-2 overflow-y-auto overflow-x-hidden p-4"><h2 class="font-bold uppercase text-lg border-gray-100 border-b-2"></h2><div class="flex flex-col gap-4"></div><div class=h-4></div><h2 class="font-bold uppercase text-lg border-gray-100 border-b-2"></h2><div class="flex flex-col gap-4">`), _tmpl$2$1 = /* @__PURE__ */ template(`<div class="absolute top-2 left-2 text-[0.5rem]"><pre>`), _tmpl$3$1 = /* @__PURE__ */ template(`<input class="w-full rounded-md shadow-sm min-w-0 shadow-black/40 h-full border-gray-100 border px-2 py-1"type=text>`), _tmpl$4$1 = /* @__PURE__ */ template(`<div class="text-xs font-bold pr-3">CM`), _tmpl$5 = /* @__PURE__ */ template(`<div class="flex items-center h-full gap-1 rounded-md shadow-sm shadow-black/40 border-gray-100 border"><input class="w-full px-2 py-1 rounded-md min-w-0 h-full "type=number>`), _tmpl$6 = /* @__PURE__ */ template(`<input class="min-w-27.5 w-full rounded-md shadow-sm shadow-black/40 h-full border-gray-100 border px-1.5 py-1.5"type=color>`), _tmpl$7 = /* @__PURE__ */ template(`<div class="w-fit relative"><button class="w-full rounded-md shadow-sm min-w-0 shadow-black/40 border-gray-100 border px-3 py-2 flex items-center justify-center gap-2 cursor-pointer"></button><div class="-top-2 w-full h-96 -translate-y-full rounded-md shadow-sm shadow-black/40 bg-white border-gray-100 border overflow-y-scroll overscroll-none no-scrollbar"><div class="flex flex-col ">`), _tmpl$8 = /* @__PURE__ */ template(`<div class="flex items-center gap-2 text-sm"><div class="flex items-center rounded-md shadow-sm shadow-black/40 h-full border-gray-100 border px-3 py-2"><label class="font-semibold text-nowrap"></label></div><div class="grow h-full">`), _tmpl$9 = /* @__PURE__ */ template(`<button class="w-full min-w-0 border-gray-200 border-b border-dashed px-3 py-2 flex items-center justify-center gap-2 cursor-pointer">`);
function SvgDrawerProperties() {
  const i18n = useI18nContext();
  const context = useSvgDrawerContext();
  const focusedItem = createMemo(() => {
    const index = context.focusedItemIndex();
    return context.items[index];
  });
  const focusedItemExtraProps = createMemo(() => {
    const item = focusedItem();
    if (!item) {
      return [];
    }
    const blueprint = SvgItems[item.kind];
    if (!blueprint) {
      return [];
    }
    return blueprint.props;
  });
  function onDeleteItem() {
    const item = focusedItem();
    if (!item) {
      return;
    }
    context.setFocusedItemIndex(-1);
    context.removeItem(item.id);
  }
  return createComponent(Show, {
    get when() {
      return focusedItem();
    },
    get children() {
      return [(() => {
        var _el$ = _tmpl$$3(), _el$2 = _el$.firstChild, _el$3 = _el$2.firstChild; _el$3.firstChild; var _el$5 = _el$3.nextSibling, _el$6 = _el$2.nextSibling, _el$7 = _el$6.firstChild, _el$8 = _el$7.nextSibling, _el$9 = _el$8.nextSibling, _el$0 = _el$9.nextSibling, _el$1 = _el$0.nextSibling;
        insert(_el$3, () => focusedItem().id, null);
        addEventListener(_el$5, "click", onDeleteItem);
        insert(_el$5, createComponent(trash_2_default, {
          stroke: "#bd50bd",
          width: "20",
          height: "20"
        }));
        insert(_el$7, () => i18n.t("category_transform"));
        insert(_el$8, createComponent(PropertyInput, {
          title: "prop_x",
          type: "number",
          get value() {
            return [focusedItem().x, (value) => context.modifyItem(focusedItem().id, {
              x: value
            })];
          }
        }), null);
        insert(_el$8, createComponent(PropertyInput, {
          title: "prop_y",
          type: "number",
          get value() {
            return [focusedItem().y, (value) => context.modifyItem(focusedItem().id, {
              y: value
            })];
          }
        }), null);
        insert(_el$8, createComponent(Switch, {
          get children() {
            return [createComponent(Match, {
              get when() {
                return focusedItem().kind === "TABLE_CIRCLE";
              },
              get children() {
                return createComponent(PropertyInput, {
                  title: "prop_radius",
                  type: "number",
                  min: 1,
                  get value() {
                    return [focusedItem().w, (value) => context.modifyItem(focusedItem().id, {
                      w: value,
                      h: value
                    })];
                  }
                });
              }
            }), createComponent(Match, {
              when: true,
              get children() {
                return [createComponent(PropertyInput, {
                  title: "prop_width",
                  type: "number",
                  min: 64,
                  get value() {
                    return [focusedItem().w, (value) => context.modifyItem(focusedItem().id, {
                      w: value
                    })];
                  }
                }), createComponent(PropertyInput, {
                  title: "prop_height",
                  type: "number",
                  min: 64,
                  get value() {
                    return [focusedItem().h, (value) => context.modifyItem(focusedItem().id, {
                      h: value
                    })];
                  }
                })];
              }
            })];
          }
        }), null);
        insert(_el$8, createComponent(PropertyInput, {
          title: "prop_angle",
          type: "number",
          get value() {
            return [focusedItem().angle, (value) => context.modifyItem(focusedItem().id, {
              angle: value
            })];
          }
        }), null);
        insert(_el$0, () => i18n.t("category_parameters"));
        insert(_el$1, createComponent(For, {
          get each() {
            return Object.keys(focusedItemExtraProps());
          },
          children: (key) => {
            const descr = focusedItemExtraProps()[key];
            return createComponent(PropertyInput, {
              get title() {
                return descr.name;
              },
              get type() {
                return descr.type;
              },
              get min() {
                return descr.min;
              },
              get value() {
                return [focusedItem()?.props?.[key], (value) => context.modifyItem(focusedItem().id, {
                  props: {
                    [key]: value
                  }
                })];
              }
            });
          }
        }));
        return _el$;
      })(), (() => {
        var _el$10 = _tmpl$2$1(), _el$11 = _el$10.firstChild;
        insert(_el$11, () => JSON.stringify(focusedItem(), null, 2));
        return _el$10;
      })()];
    }
  });
}
function PropertyInput(props) {
  let dom = null;
  const i18n = useI18nContext();
  const [menuOpen, setMenuOpen] = createSignal(false);
  const formattedValue = createMemo(() => {
    if (props.type == "number") {
      return props.value[0].toFixed(2).replace(",", ".");
    } else {
      return props.value[0];
    }
  });
  onMount(() => {
    if (props.type == "icon") {
      window.addEventListener("pointerdown", onWindowPointerDown);
      window.addEventListener("wheel", onWindowScroll);
    }
  });
  onCleanup(() => {
    window.removeEventListener("pointerdown", onWindowPointerDown);
    window.removeEventListener("wheel", onWindowScroll);
  });
  function onWindowPointerDown(e) {
    const target = e.target;
    const isTargetingMenu = target == dom || dom.contains(target);
    if (!isTargetingMenu) {
      setMenuOpen(false);
    }
  }
  function onWindowScroll(e) {
    const target = e.target;
    const isTargetingMenu = target == dom || dom.contains(target);
    if (!isTargetingMenu) {
      setMenuOpen(false);
    }
  }
  function updateValue(value) {
    if (props.type == "number") {
      value = parseFloat(value);
      if (props.min != void 0) {
        value = Math.max(value, props.min);
      }
    } else if (props.type == "string") {
      value = value;
    } else if (props.type == "color") {
      value = value;
    } else {
      value = value;
    }
    props.value[1]?.(value);
  }
  function onChange(e) {
    const input = e.target;
    updateValue(input.value);
  }
  return (() => {
    var _el$12 = _tmpl$8(), _el$13 = _el$12.firstChild, _el$14 = _el$13.firstChild, _el$15 = _el$13.nextSibling;
    insert(_el$14, () => i18n.t(props.title) ?? props.title);
    var _ref$ = dom;
    typeof _ref$ === "function" ? use(_ref$, _el$15) : dom = _el$15;
    insert(_el$15, createComponent(Show, {
      get when() {
        return props.type == "string";
      },
      get children() {
        var _el$16 = _tmpl$3$1();
        _el$16.$$input = onChange;
        createRenderEffect(() => _el$16.value = formattedValue());
        return _el$16;
      }
    }), null);
    insert(_el$15, createComponent(Show, {
      get when() {
        return props.type == "number";
      },
      get children() {
        var _el$17 = _tmpl$5(), _el$18 = _el$17.firstChild;
        _el$18.$$input = onChange;
        insert(_el$17, createComponent(Show, {
          get when() {
            return memo(() => props.title !== "prop_seats")() && props.title !== "prop_angle";
          },
          get children() {
            return _tmpl$4$1();
          }
        }), null);
        createRenderEffect(() => setAttribute(_el$18, "min", props.min));
        createRenderEffect(() => _el$18.value = formattedValue());
        return _el$17;
      }
    }), null);
    insert(_el$15, createComponent(Show, {
      get when() {
        return props.type == "color";
      },
      get children() {
        var _el$20 = _tmpl$6();
        _el$20.$$input = onChange;
        createRenderEffect(() => _el$20.value = formattedValue());
        return _el$20;
      }
    }), null);
    insert(_el$15, createComponent(Show, {
      get when() {
        return props.type == "icon";
      },
      get children() {
        var _el$21 = _tmpl$7(), _el$22 = _el$21.firstChild, _el$23 = _el$22.nextSibling, _el$24 = _el$23.firstChild;
        addEventListener(_el$22, "click", () => setMenuOpen(!menuOpen()));
        insert(_el$22, createComponent(SvgIcon, {
          get icon() {
            return formattedValue();
          },
          width: "48",
          height: "48"
        }));
        insert(_el$24, createComponent(For, {
          get each() {
            return Object.keys(SPRITES_META);
          },
          children: (key) => {
            return (() => {
              var _el$25 = _tmpl$9();
              addEventListener(_el$25, "click", () => {
                updateValue(key);
                setMenuOpen(false);
              });
              insert(_el$25, createComponent(SvgIcon, {
                icon: key,
                width: "48",
                height: "48"
              }));
              return _el$25;
            })();
          }
        }));
        createRenderEffect((_p$) => {
          var _v$ = !!menuOpen(), _v$2 = !menuOpen();
          _v$ !== _p$.e && _el$23.classList.toggle("absolute", _p$.e = _v$);
          _v$2 !== _p$.t && _el$23.classList.toggle("hidden", _p$.t = _v$2);
          return _p$;
        }, {
          e: void 0,
          t: void 0
        });
        return _el$21;
      }
    }), null);
    return _el$12;
  })();
}
delegateEvents(["input"]);

function createSvgBlobFromSvg(svg) {
  const serializer = new XMLSerializer();
  let source = serializer.serializeToString(svg);
  if (!source.startsWith("<?xml")) {
    source = `<?xml version="1.0" encoding="UTF-8"?>
${source}`;
  }
  const blob = new Blob([source], {
    type: "image/svg+xml;charset=utf-8"
  });
  const url = URL.createObjectURL(blob);
  return url;
}
function createPngBlobFromSvg(svg) {
  return new Promise((resolve, reject) => {
    const scale = window.devicePixelRatio || 1;
    const width = svg.clientWidth;
    const height = svg.clientHeight;
    const svgBlobUrl = createSvgBlobFromSvg(svg);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = width * scale;
      canvas.height = height * scale;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
      ctx.drawImage(
        img,
        0,
        0,
        width,
        height
      );
      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error("Couldn't create blob from canvas"));
          return;
        }
        resolve(URL.createObjectURL(blob));
      }, "image/png");
    };
    img.src = svgBlobUrl;
  });
}
function openBlobInWindow(url) {
  window.open(url, "_blank");
}
function saveBlobToFile(url, ext) {
  const now = /* @__PURE__ */ new Date();
  const timestamp = now.toISOString().replace(/[:.]/g, "-");
  const a = document.createElement("a");
  a.href = url;
  a.download = `image-${timestamp}.${ext}`;
  a.click();
}

var _tmpl$$2 = /* @__PURE__ */ template(`<button>New guest`), _tmpl$2 = /* @__PURE__ */ template(`<div class="flex flex-col justify-end w-32 h-full gap-4"><div class="grow overflow-y-auto p-2 flex flex-col gap-4 no-scrollbar"></div><div class="flex flex-col gap-2"><div class=relative><button class="rounded-md w-full px-4 py-2 text-sm font-semibold border-gray-800 border bg-black text-white shadow-md shadow-black/60 cursor-pointer"></button><div class="-top-2 left-0 -translate-y-full w-64 h-fit overflow-y-scroll no-scrollbar bg-white border-gray-200 border rounded-md shadow-md shadow-black/20"><div class="flex flex-col p-2"><div class="bg-white border-gray-200 border-b-2 border-dashed pb-2 px-1 font-semibold"><div class="flex items-center justify-between py-1"><p class=pl-1>SVG</p><div class="flex gap-2"><button class="rounded-md p-2 border-gray-200 border cursor-pointer"></button><button class="rounded-md p-2 border-gray-200 border cursor-pointer"></button></div></div></div><div class="bg-white pt-2 px-1 font-semibold"><div class="flex items-center justify-between py-1"><p class=pl-1>PNG</p><div class="flex gap-2"><button class="rounded-md p-2 border-gray-200 border cursor-pointer"></button><button class="rounded-md p-2 border-gray-200 border cursor-pointer">`), _tmpl$3 = /* @__PURE__ */ template(`<h3 class="uppercase text-sm font-semibold border-b border-dashed border-gray-300">`), _tmpl$4 = /* @__PURE__ */ template(`<button class="p-4 rounded-md shadow-inner shadow-black/40 flex justify-center cursor-pointer">`);
const config = {
  groups: [{
    name: "category_tables",
    items: [{
      blueprint: SvgItems.TABLE_RECT,
      icon: "square-table"
    }, {
      blueprint: SvgItems.TABLE_T,
      icon: "t-table"
    }, {
      blueprint: SvgItems.TABLE_U,
      icon: "u-table"
    }, {
      blueprint: SvgItems.TABLE_CIRCLE,
      icon: "round-table"
    }]
  }, {
    name: "category_icons",
    items: []
  }]
};
for (const icon in SPRITES_META) {
  if (icon === "square-table" || icon === "t-table" || icon === "u-table" || icon === "round-table") {
    continue;
  }
  config.groups[1].items.push({
    blueprint: SvgItems.ICON,
    icon,
    overwrite: {
      icon
    }
  });
}
function AppBottomMenu() {
  let exportControlDOM = null;
  const i18n = useI18nContext();
  const canvas = useSvgDrawerContext();
  const [showExportPicker, setShowExportPicker] = createSignal(false);
  const [group, setGroup] = createSignal("icons");
  onMount(() => {
    document.addEventListener("pointerdown", onWindowPointerDown);
  });
  onCleanup(() => {
    document.removeEventListener("pointerdown", onWindowPointerDown);
  });
  function onWindowPointerDown(e) {
    const target = e.target;
    if (target != exportControlDOM && !exportControlDOM.contains(target)) {
      setShowExportPicker(false);
    }
  }
  async function openBlob(type) {
    const rootDOM = canvas.rootDOM();
    if (!rootDOM) {
      return;
    }
    const url = type == "svg" ? createSvgBlobFromSvg(rootDOM) : await createPngBlobFromSvg(rootDOM);
    openBlobInWindow(url);
    setShowExportPicker(false);
  }
  async function downloadBlob(type) {
    const rootDOM = canvas.rootDOM();
    if (!rootDOM) {
      return;
    }
    const url = type == "svg" ? createSvgBlobFromSvg(rootDOM) : await createPngBlobFromSvg(rootDOM);
    saveBlobToFile(url, type);
    setShowExportPicker(false);
  }
  async function createSvgItemFromPicker(item) {
    const svgItem = createSvgItemFromBlueprint(item.blueprint);
    for (const key in item.overwrite) {
      if (!item.blueprint.props[key]) {
        continue;
      }
      svgItem.props[key] = item.overwrite[key];
    }
    svgItem.x = -canvas.panX();
    svgItem.y = -canvas.panY();
    canvas.addItem(svgItem.id, svgItem);
    canvas.setFocusedItemIndex(svgItem.id);
  }
  return (() => {
    var _el$ = _tmpl$2(), _el$2 = _el$.firstChild, _el$4 = _el$2.nextSibling, _el$5 = _el$4.firstChild, _el$6 = _el$5.firstChild, _el$7 = _el$6.nextSibling, _el$8 = _el$7.firstChild, _el$9 = _el$8.firstChild, _el$0 = _el$9.firstChild, _el$1 = _el$0.firstChild, _el$10 = _el$1.nextSibling, _el$11 = _el$10.firstChild, _el$12 = _el$11.nextSibling, _el$13 = _el$9.nextSibling, _el$14 = _el$13.firstChild, _el$15 = _el$14.firstChild, _el$16 = _el$15.nextSibling, _el$17 = _el$16.firstChild, _el$18 = _el$17.nextSibling;
    insert(_el$2, createComponent(Switch, {
      get children() {
        return [createComponent(Match, {
          get when() {
            return group() === "icons";
          },
          get children() {
            return createComponent(For, {
              get each() {
                return config.groups;
              },
              children: (group2) => [(() => {
                var _el$19 = _tmpl$3();
                insert(_el$19, () => i18n.t_dynamic(group2.name));
                return _el$19;
              })(), createComponent(For, {
                get each() {
                  return group2.items;
                },
                children: (item) => (() => {
                  var _el$20 = _tmpl$4();
                  addEventListener(_el$20, "click", () => createSvgItemFromPicker(item));
                  insert(_el$20, createComponent(SvgIcon, {
                    get icon() {
                      return item.icon;
                    },
                    width: "64",
                    height: "64",
                    inline: true
                  }));
                  return _el$20;
                })()
              })]
            });
          }
        }), createComponent(Match, {
          get when() {
            return group() === "guests";
          },
          get children() {
            return _tmpl$$2();
          }
        })];
      }
    }));
    var _ref$ = exportControlDOM;
    typeof _ref$ === "function" ? use(_ref$, _el$5) : exportControlDOM = _el$5;
    _el$6.$$click = () => setShowExportPicker(!showExportPicker());
    insert(_el$6, () => i18n.t("export"));
    addEventListener(_el$11, "click", () => openBlob("svg"));
    insert(_el$11, createComponent(external_link_default, {
      width: "16",
      height: "16"
    }));
    addEventListener(_el$12, "click", () => downloadBlob("svg"));
    insert(_el$12, createComponent(download_default, {
      width: "16",
      height: "16"
    }));
    addEventListener(_el$17, "click", () => openBlob("png"));
    insert(_el$17, createComponent(external_link_default, {
      width: "16",
      height: "16"
    }));
    addEventListener(_el$18, "click", () => downloadBlob("png"));
    insert(_el$18, createComponent(download_default, {
      width: "16",
      height: "16"
    }));
    createRenderEffect((_p$) => {
      var _v$ = !!showExportPicker(), _v$2 = !showExportPicker();
      _v$ !== _p$.e && _el$7.classList.toggle("absolute", _p$.e = _v$);
      _v$2 !== _p$.t && _el$7.classList.toggle("hidden", _p$.t = _v$2);
      return _p$;
    }, {
      e: void 0,
      t: void 0
    });
    return _el$;
  })();
}
delegateEvents(["click"]);

const API_ENDPOINTS = {
  GUEST: {
    endpoint: "/guest/getlist/:id",
    method: ["GET"]
  },
  GET_ELEMENTS: {
    endpoint: "/element/ballroom/:id",
    method: ["GET"]
  },
  ADD_ELEMENTS: {
    endpoint: "/element",
    method: ["POST"]
  },
  UPDATE_ELEMENT: {
    endpoint: "/element/:id",
    method: ["PUT"]
  },
  DELETE_ELEMENT: {
    endpoint: "/element/:id",
    method: ["DELETE"]
  }
};

const BASE_URL = "https://afrosmoky.vps.webdock.cloud/api";
function apiQuery(options) {
  console.log(`Will be quering with ballrom ${options.id}`);
  const fetcher = async (opts) => {
    const endpointTemplate = API_ENDPOINTS[opts.route].endpoint;
    const endpoint = opts.id ? endpointTemplate.replace(":id", opts.id) : endpointTemplate.replace("/:id", "");
    const res = await fetch(`${BASE_URL}${endpoint}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    });
    if (!res.ok) {
      throw new Error(`API error: ${res.status}`);
    }
    const json = await res.json();
    if ("data" in json) {
      return json.data;
    }
    return json;
  };
  const source = typeof options === "function" ? options : () => options;
  const [data, {
    refetch
  }] = createResource(source, fetcher);
  return {
    data,
    refetch
  };
}

var _tmpl$$1 = /* @__PURE__ */ template(`<div class="absolute top-0 bottom-0 left-0 p-2 border-r border-gray-300 bg-white shadow-black/40 shadow-md">`);
const backendTypeToBlueprint = {
  ["TABLE_RECT"]: SvgItems.TABLE_RECT,
  ["square-table"]: SvgItems.TABLE_RECT,
  ["TABLE_CIRCLE"]: SvgItems.TABLE_CIRCLE,
  ["TABLE_T"]: SvgItems.TABLE_T,
  ["TABLE_U"]: SvgItems.TABLE_U,
  ["ICON"]: SvgItems.ICON
};
function debounce(callback, wait) {
  let timer;
  return (...args) => {
    if (timer) clearTimeout(timer);
    return new Promise((resolve) => {
      timer = setTimeout(() => resolve(callback(...args)), wait);
    });
  };
}
function App() {
  const [searchParams] = useSearchParams();
  const ballroomId = createMemo(() => {
    return (Array.isArray(searchParams.ballroom) ? searchParams.ballroom[0] : searchParams.ballroom) || "1";
  });
  const canvas = useSvgDrawerContext();
  const ballroomAPI = apiQuery({
    route: "GET_ELEMENTS",
    id: ballroomId()
  });
  const BASE_URL = "https://afrosmoky.vps.webdock.cloud/api";
  let [processedPatches, setProcessedPatches] = createSignal(0);
  createEffect(() => {
    const data = ballroomAPI.data();
    if (data) {
      queueMicrotask(() => {
        updateItemsFromServer(data);
      });
    }
  });
  const patchQueue = [];
  let flushing = false;
  let pollInterval;
  onMount(() => {
    pollInterval = setInterval(() => {
      if (flushing) {
        return;
      }
      ballroomAPI.refetch();
    }, 3e3);
  });
  onCleanup(() => {
    clearInterval(pollInterval);
  });
  const flushDebounced = debounce(flush, 500);
  function emit(patch) {
    patchQueue.push(patch);
    if (!flushing) {
      flushDebounced();
    }
  }
  async function flush() {
    if (flushing) {
      return;
    }
    flushing = true;
    try {
      while (patchQueue.length > 0) {
        const batch = patchQueue.splice(0);
        await sendPatchesToBackend(batch);
      }
    } finally {
      flushing = false;
    }
  }
  createEffect(() => {
    let processed = processedPatches();
    while (processed < canvas.patches.length) {
      emit(unwrap(canvas.patches[processed]));
      processed++;
    }
    setProcessedPatches(processed);
  });
  async function sendPatchesToBackend(patches) {
    const finalPatches = [];
    let toMerge = null;
    for (const patch of patches) {
      if (!toMerge) {
        toMerge = patch;
        continue;
      }
      const newPatch = mergePatches(toMerge, patch);
      if (newPatch) {
        toMerge = newPatch;
      } else {
        finalPatches.push(toMerge);
        toMerge = null;
      }
    }
    if (toMerge) {
      finalPatches.push(toMerge);
    }
    for (const patch of finalPatches) {
      try {
        await sendPatchToServer(patch);
      } catch (error) {
        console.error(error);
      }
    }
  }
  async function sendPatchToServer(patch) {
    if (patch.type === "mod") {
      if (!canvas.items[patch.id]) {
        console.warn("wanted to send mod patch but item no longer exists");
        return;
      }
      console.log(`Sending MOD patch for item ${patch.id} with values: `);
      console.log(patch.value);
      const endpointTemplate = API_ENDPOINTS.UPDATE_ELEMENT.endpoint;
      const endpoint = endpointTemplate.replace(":id", patch.id.toString());
      const item = createBackendFromItem(canvas.items[patch.id]);
      await fetch(`${BASE_URL}${endpoint}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(item)
      });
    } else if (patch.type === "add") {
      console.log(`Sending ADD patch for item ${patch.id}`);
      const endpoint = API_ENDPOINTS.ADD_ELEMENTS.endpoint;
      const item = createBackendFromItem(patch.item);
      item.id = void 0;
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(item)
      });
      const body = await response.json();
      const backendId = body.data.id;
      const shouldFocus = canvas.focusedItemIndex() === patch.id;
      canvas.removeItem(patch.id, false);
      canvas.addItem(backendId, createItemFromBackend(body.data), false);
      shouldFocus && canvas.setFocusedItemIndex(backendId);
    } else if (patch.type === "del") {
      console.log(`Sending DEL patch for item ${patch.id}`);
      const endpointTemplate = API_ENDPOINTS.DELETE_ELEMENT.endpoint;
      const endpoint = endpointTemplate.replace(":id", patch.id.toString());
      await fetch(`${BASE_URL}${endpoint}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
  }
  function updateItemsFromServer(items) {
    for (const key in canvas.items) {
      const backendExists = items.findIndex((o) => o.id === parseInt(key)) != -1;
      if (!backendExists) {
        canvas.removeItem(parseInt(key), false);
      }
    }
    for (const backendItem of items) {
      const item = createItemFromBackend(backendItem);
      if (!canvas.items[backendItem.id]) {
        if (canvas.removed_ids.has(backendItem.id)) {
          console.warn(`Won't create server item, cause it's already deleted`);
          continue;
        }
        canvas.addItem(backendItem.id, item, false);
      } else {
        const unwraped = unwrap(canvas.items[backendItem.id]);
        if (unwraped.last_update > item.last_update) {
          console.warn("Wanted to update from server, but client is newer");
          console.log(`Client: ${new Date(unwraped.last_update)}`);
          console.log(`Server: ${new Date(item.last_update)}`);
          return;
        }
        const diff = getItemDiff(unwraped, item);
        if (!diff) {
          continue;
        }
        console.log(`Detected diff for item ${backendItem.id}`);
        console.log(diff);
        canvas.modifyItem(backendItem.id, diff, false);
      }
    }
  }
  function createItemFromBackend(backend) {
    const blueprint = backendTypeToBlueprint[backend.kind];
    if (!blueprint) {
      console.warn(`Couldn't create item from backend!`);
      console.warn(backend);
      return;
    }
    const lastUpdated = new Date(backend.updated_at).getTime() + 60 * 60 * 1e3;
    const item = createSvgItemFromBlueprint(blueprint, backend.id);
    item.x = typeof backend.x === "number" ? backend.x : parseFloat(backend.x) ?? 0;
    item.y = typeof backend.y === "number" ? backend.y : parseFloat(backend.y) ?? 0;
    item.w = parseFloat(backend.config.width?.toString()) ?? 64;
    item.h = parseFloat(backend.config.height?.toString()) ?? 64;
    item.angle = parseFloat(backend.config.angle?.toString()) ?? 0;
    item.last_update = lastUpdated;
    if (isSvgItemTable(item)) {
      item.props.name = backend.name ?? "";
      item.props.seat_spacing = parseFloat(backend.spacing?.toString()) ?? 0;
      item.props.color = backend.color ?? "#aaaaaa";
    } else if (isSvgItemIcon(item)) {
      item.props.label = backend.name ?? "";
      item.props.icon = backend.icon ?? "air-conditioner";
    }
    return item;
  }
  function createBackendFromItem(item) {
    const backend = {
      ballroom_id: ballroomId(),
      id: item.id,
      name: (isSvgItemTable(item) ? item.props.name : isSvgItemIcon(item) ? item.props.label : "") || "",
      index: "",
      focus: "",
      icon: isSvgItemIcon(item) ? item.props.icon : "",
      x: item.x,
      y: item.y,
      color: isSvgItemTable(item) ? item.props.color : "",
      kind: item.kind,
      spacing: isSvgItemTable(item) ? item.props.seat_spacing : -1,
      status: "active",
      config: {
        seats: -1,
        radius: isSvgItemTable(item) ? item.props.seat_radius : -1,
        width: item.w,
        height: item.h,
        size: -1,
        angle: item.angle,
        angle_origin_x: -1,
        angle_origin_y: -1
      }
    };
    return backend;
  }
  return [createComponent(SvgDrawer, {}), createComponent(SvgDrawerProperties, {}), (() => {
    var _el$ = _tmpl$$1();
    insert(_el$, createComponent(AppBottomMenu, {}));
    return _el$;
  })()];
}

var _tmpl$ = /* @__PURE__ */ template(`<main class="w-screen h-screen">`);
function Root() {
  return (() => {
    var _el$ = _tmpl$();
    insert(_el$, createComponent(I18nContextProvider, {
      get children() {
        return createComponent(SvgDrawerContextProvider, {
          get children() {
            return createComponent(App, {});
          }
        });
      }
    }));
    return _el$;
  })();
}

document.getElementById("spa-loader").outerHTML = "";
render(() => createComponent(Router, {
  get children() {
    return createComponent(Route, {
      path: "/svg-editor",
      component: Root
    });
  }
}), document.body);

export { spread as s, template as t };
