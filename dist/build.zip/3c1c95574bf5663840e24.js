import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=256 cy=256 r=150 stroke=#000 stroke-linejoin=round stroke-width=5></circle><path stroke=#000 stroke-width=5 d="M223.5 177c0-11.874 9.626-21.5 21.5-21.5h22c11.874 0 21.5 9.626 21.5 21.5v50c0 11.874-9.626 21.5-21.5 21.5h-22c-11.874 0-21.5-9.626-21.5-21.5z"></path><path stroke=#000 stroke-linecap=square stroke-width=5 d="M256.048 251v87.585m0 0L226 354m30.048-15.415L284 354m-27.952-15.415 16.072-7.707M227 190h14M226 210h15">`);
const microphone = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { microphone as default };
