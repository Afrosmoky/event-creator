import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=215.05 height=212.812 fill=none viewBox="126.867 143.739 223.05 220.812"><path stroke=#000 stroke-width=5 d="m134.467 147.739 211.45 212.812M130.867 360.497l211.557-212.706"></path><circle cx=238 cy=252 r=22.5 stroke=#000 stroke-width=5>`);
const target = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { target as default };
