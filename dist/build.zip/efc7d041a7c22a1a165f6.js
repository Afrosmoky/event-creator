import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=256 cy=256 r=150 stroke=#000 stroke-linejoin=round stroke-width=5></circle><path stroke=#000 stroke-width=5 d="m256 132.09 3.235 9.957.561 1.728h12.286l-8.47 6.153-1.469 1.068.561 1.727 3.235 9.957-8.47-6.153-1.469-1.068-1.469 1.068-8.47 6.153 3.235-9.957.561-1.727-1.469-1.068-8.47-6.153h12.286l.561-1.728zM288 157.09l.99 3.047.561 1.728h5.021l-2.592 1.883-1.47 1.068.561 1.727.99 3.047-2.592-1.883-1.469-1.068-1.469 1.068-2.592 1.883.99-3.047.561-1.727-1.47-1.068-2.592-1.883h5.021l.561-1.728zM238.5 230.5h45v75h-45zM255.5 306.5h11v34h-11zM234.387 229.5 260 191.475l25.613 38.025z"></path><path stroke=#000 stroke-linecap=square stroke-width=5 d="M240 305c.8-2 28.333-48.833 42-72v2M262 304.5l19.5-28.5M240 267.5l19.5-34"></path><path stroke=#000 stroke-width=5 d="m307.489 346 17.56 9.573M186 355.54l17.786-9.148M262 372.54l.011 20">`);
const firework = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { firework as default };
