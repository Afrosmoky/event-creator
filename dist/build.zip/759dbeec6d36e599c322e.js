import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=248.003 height=304 fill=none viewBox="128 98 256.003 312"><path stroke=#000 stroke-miterlimit=10 stroke-width=10 d="M309.677 323.569c-1.939 47.17-43.615 84.35-92.331 82.354s-87.202-42.462-85.277-89.632c1.939-47.17 43.615-84.35 92.331-82.355M276.024 169.446c18.625 0 33.723-15.098 33.723-33.723S294.649 102 276.024 102s-33.723 15.098-33.723 33.723 15.098 33.723 33.723 33.723Z"></path><path stroke=#000 stroke-miterlimit=10 stroke-width=10 d="m239.491 301.312 3.232-92.71c.548-15.695 13.432-28.131 29.128-28.131h9.189c14.824 0 27.625 10.384 30.702 24.885L318.5 251.5c2.487 11.719 15.274 17.494 27.26 17.494 14.501 0 26.515 11.283 27.4 25.756l6.843 110.541h-44.219l-11.213-75.624c-2.08-14.037-13.77-24.674-27.948-25.404z"></path><path stroke=#000 stroke-linecap=round stroke-miterlimit=10 stroke-width=10 d="M224.359 238.395V185H132"></path><path stroke=#000 stroke-miterlimit=10 stroke-width=10 d="M224.737 320.281h62.528c0 34.299-28.229 62.528-62.528 62.528s-62.528-28.229-62.528-62.528 28.229-62.528 62.528-62.528z">`);
const disabilitySing = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { disabilitySing as default };
