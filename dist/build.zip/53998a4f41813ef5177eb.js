import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=251.148 height=217.5 fill=none viewBox="126.426 107 259.148 225.5"><path stroke=#000 stroke-width=5 d="M130.426 328.5 256 111l125.574 217.5z"></path><path stroke=#000 stroke-linecap=round stroke-width=10 d="M258 187v90"></path><path fill=#000 stroke=#000 d="M253.5 302.5h9v9h-9z">`);
const cautionSign = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { cautionSign as default };
