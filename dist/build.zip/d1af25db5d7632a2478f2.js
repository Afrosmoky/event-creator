import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=150 cy=150 r=150 stroke=#000 stroke-linejoin=round stroke-width=5 transform="matrix(-1 0 0 1 406 106)"></circle><path stroke=#000 stroke-width=5 d="M256 356V156M343 207l-174.64 97.472M335 317.78 177.906 194M279.5 162.5l-24 25.5-23-25.5M197.138 178l4.811 34.686-34.286 1.923M168.192 276.39l33.535 10.083-12.542 31.968M233.007 344.31l23.555-25.912L280 343.496M306.734 325.886l-5.939-34.51 34.205-3.04M346 233.258l-33.88-8.854L323.488 192">`);
const airConditioner = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { airConditioner as default };
