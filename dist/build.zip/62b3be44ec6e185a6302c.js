import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=295 height=195 fill=none viewBox="79.5 103.5 303 203"><rect width=295 height=195 x=83.5 y=107.5 stroke=#000 stroke-width=5 rx=40.5></rect><path stroke=#000 stroke-width=5 d="M108.5 241.5h106v38h-106z"></path><circle cx=162 cy=178 r=47.5 stroke=#000 stroke-width=5></circle><path stroke=#000 stroke-width=5 d="M175.755 196.896c-9.913 9.611-25.74 9.367-35.352-.545s-9.368-25.739.545-35.351M141 241.5v38m39.5-38v38M247.5 241.5h106v38h-106z"></path><circle cx=301 cy=178 r=47.5 stroke=#000 stroke-width=5></circle><path stroke=#000 stroke-width=5 d="M314.755 196.896c-9.913 9.611-25.74 9.367-35.352-.545s-9.368-25.739.545-35.351M280 241.5v38m39.5-38v38">`);
const djController = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { djController as default };
