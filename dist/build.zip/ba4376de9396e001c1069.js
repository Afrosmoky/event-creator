import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=216.5 height=305.546 fill=none viewBox="148 56.454 224.5 313.546"><path stroke=#000 stroke-width=5 d="M258.478 106.063 368.5 366l-110.022-56.5L152 366z"></path><path fill=#000 stroke=#000 d="M259 309V107L152.5 365z"></path><path fill=#000 d="M276.545 60.455V107h-5.454l-25.364-36.546h-.454V107h-5.637V60.455h5.455l25.454 36.636H271V60.455z">`);
const compass = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { compass as default };
