import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=256 cy=256 r=150 stroke=#000 stroke-linejoin=round stroke-width=5></circle><path stroke=#000 stroke-linecap=round stroke-width=10 d="m283 195-54 60.555h54L229 317">`);
const electricalOutlet = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { electricalOutlet as default };
