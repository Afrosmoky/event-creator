import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=304.05 height=325.5 fill=none viewBox="97.95 73.5 312.05 333.5"><path stroke=#000 stroke-miterlimit=10 stroke-width=5 d="M406 402.5H106"></path><path stroke=#000 stroke-dasharray="12 12"stroke-miterlimit=10 stroke-width=5 d="M405.5 403V103M393.5 77.5l9.06 13.5C238.13 91 104.22 223.12 102 387.54l-.05 3.46M393.5 103.5l9.06-12.5">`);
const rightDoor = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { rightDoor as default };
