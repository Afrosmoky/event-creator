import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=230.965 height=218.182 fill=none viewBox="146.138 121.49 238.965 226.182"><path fill=#000 fill-opacity=.62 d="M221.302 343.672h-27.699l80.114-218.182h27.272l80.114 218.182h-27.699l-65.199-183.665h-1.704zm10.227-85.227h111.648v23.437H231.529z"></path><path fill=#000 d="M177.837 343.672h-27.699l80.114-218.181h27.273l80.113 218.181h-27.699l-65.198-183.664h-1.705zm10.227-85.227h111.648v23.438H188.064z">`);
const label = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { label as default };
