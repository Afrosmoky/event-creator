import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=256 cy=256 r=150 stroke=#000 stroke-linejoin=round stroke-width=5></circle><path stroke=#000 stroke-width=5 d="M144 256h30M174 226v60"></path><path stroke=#000 stroke-linecap=square stroke-width=5 d="M174 226.5h16.5v59H174M191.5 227l67.5-41.5V328l-67.5-42.5M261 233.5s17.763 13.298 18 26.5c.243 13.51-18 27.5-18 27.5"></path><ellipse cx=305.547 cy=225.957 fill=#000 rx=11.547 ry=9.043></ellipse><path stroke=#000 stroke-linecap=square stroke-width=3 d="m314.785 228.041 23.15-42.407 9.443 21.792"></path><ellipse cx=301.028 cy=188.25 fill=#000 rx=7.028 ry=5.75></ellipse><path stroke=#000 stroke-linecap=square stroke-width=2 d="m306.778 188.467 7.474-16.96 4.665 7.997">`);
const sound = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { sound as default };
