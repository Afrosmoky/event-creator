import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><path fill=#000 stroke=#000 stroke-width=5 d="M406 106h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-18 0h-9v.75h9zm-11.25 6H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v9h.75zm0 18H106v6h3v-.75h-2.25zm20.25 5.25h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm18 0h-9v.75h9zm9-8.25h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75zm0-18h-.75v9h.75z">`);
const stage = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { stage as default };
