import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=256 cy=256 r=150 stroke=#000 stroke-linejoin=round stroke-width=5></circle><path stroke=#000 stroke-linecap=square stroke-width=5 d="m287 185.23-63-31.491s5.412 23.091 15.113 28.636c6.251 3.574 18.075-1.424 18.075-1.424"></path><path stroke=#000 stroke-width=5 d="M192.5 214.5h126v57h-126zM178.5 271.5h159v75h-159z"></path><path stroke=#000 stroke-width=5 d="M178.5 272.5s9.608 24.612 23.5 28.5c15.086 4.222 21.478-13.383 37-15.5 23.23-3.169 35.124 20.636 58 15.5 18.87-4.237 40.5-28.5 40.5-28.5M193.896 246.346c-12.281 8.274 7.281-15.928 19.858-16.346 10.992-.365 21.851 10.525 32.848 10.658 12.872.156 16.435-17.421 29.168-15.513 10.043 1.505 10.925 14.097 20.98 15.513 8.892 1.252 22.004-6.722 22.004-6.722">`);
const cake = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { cake as default };
