import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=211 height=353.5 fill=none viewBox="173 43.5 219 361.5"><path stroke=#000 stroke-width=5 d="m388 401-14-177H259.5L239 401M214.5 200.5l-5 54.5h18l7.5-37.5m121-4.5h24.5V84.5H351l-3 73H177l18.5 29 24 4L241 213z"></path><circle cx=20 cy=20 r=17.5 stroke=#000 stroke-width=5 transform="matrix(-1 0 0 1 319 45)"></circle><path stroke=#000 stroke-width=5 d="m260.5 149.5 15.5-48h44.5l15.5 48">`);
const highChairSign = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { highChairSign as default };
