import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=234.004 height=199.123 fill=none viewBox="135.394 151.529 242.004 207.123"><path fill=#000 d="M373.388 160.219a2.5 2.5 0 0 0-2.272-2.709l-22.413-1.971a2.5 2.5 0 1 0-.438 4.981l19.923 1.751-1.752 19.924a2.5 2.5 0 0 0 4.981.438zM142.606 354.652l229.897-192.736-3.212-3.832-229.897 192.737z">`);
const arrow = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { arrow as default };
