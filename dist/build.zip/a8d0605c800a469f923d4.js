import { t as template, s as spread } from './c1206700af0e361094e1f.js';

var _tmpl$ = /*#__PURE__*/template(`<svg xmlns=http://www.w3.org/2000/svg width=300 height=300 fill=none viewBox="102 102 308 308"><circle cx=256 cy=256 r=150 stroke=#000 stroke-linejoin=round stroke-width=5></circle><path stroke=#000 stroke-width=5 d="M304.5 241.182c0 16.738-14.938 31.175-27.5 46.818-5.5 11-2.5 4-7 18.5h-24.5s-5.16-16.641-10.5-21c-14.396-11.753-28-21.483-28-44.318C207 209.877 228.886 190 256.5 190s48 19.877 48 51.182ZM245 317h27.474L245 330h29M312 256h20M176 256h20M305.489 205.539l17.56-9.573M186 196l17.786 9.147M258 179l.011-20">`);
const light = (props = {}) => (() => {
  var _el$ = _tmpl$();
  spread(_el$, props, true, true);
  return _el$;
})();

export { light as default };
